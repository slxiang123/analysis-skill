from typing import Any

from .sweep_analysis_toolbox import SweepAnalysisToolbox

__all__ = ["SweepAnalysisToolbox", "main"]


def main() -> dict[str, Any]:
    """运行 ``sim_result_analysis`` 中定义的完整扫频流程案例。"""
    from .sim_result_analysis import main as run_sweep_analysis

    return run_sweep_analysis()
