"""完整的 CloudPSS 单次扫频分析流程案例。"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Any

import nest_asyncio
import numpy as np
from dotenv import load_dotenv

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from sweepanalysis.sweep_analysis_toolbox import SweepAnalysisToolbox
else:
    from .sweep_analysis_toolbox import SweepAnalysisToolbox

load_dotenv()
nest_asyncio.apply()


def main() -> dict[str, Any]:
    """从环境变量读取配置并运行完整的单次扫频分析流程。

    流程包括获取并修改模型、添加扫频源和输出通道、创建计算方案、运行
    仿真、解析频谱、保存结果以及生成稳定性和奈奎斯特诊断图。

    必填环境变量：
        ``SIMSTUDIO_TOKEN``（或 ``CLOUDPSS_TOKEN``）、``CLOUDPSS_MODEL``
        和 ``CLOUDPSS_COMPONENT_KEY``。

    可选环境变量：
        ``CLOUDPSS_API_URL``、``SWEEP_TESTED_PIN``、``SWEEP_SAMPLE_FREQ``、
        ``SWEEP_N_CPU``、``SWEEP_SOLVER_OPTION``、``SWEEP_SAVE_PATH``、
        ``SWEEP_INJECTION_TYPE`` 和 ``SWEEP_SHOW_PLOTS``。

    Returns:
        包含运行器 ID、扫频参数、频谱数据、保存文件路径和谐振风险的字典。

    Raises:
        RuntimeError: 必填配置缺失或扫频仿真运行失败。
        ValueError: 模型路径、注入类型、目标元件或引脚无效。
    """
    project_root = Path(__file__).resolve().parents[2]
    os.chdir(project_root)

    cloudpss_token = os.getenv("SIMSTUDIO_TOKEN") or os.getenv(
        "CLOUDPSS_TOKEN", ""
    )
    cloudpss_api_url = os.getenv("CLOUDPSS_API_URL", "https://cloudpss.net/")
    cloudpss_model = os.getenv("CLOUDPSS_MODEL", "")
    component_key = os.getenv("CLOUDPSS_COMPONENT_KEY") or os.getenv(
        "CLOUDPSS_COMP_KEY", ""
    )
    tested_pin = os.getenv("SWEEP_TESTED_PIN", "0")
    sample_freq = float(os.getenv("SWEEP_SAMPLE_FREQ", "100"))
    n_cpu = int(os.getenv("SWEEP_N_CPU", "1"))
    solver_option = int(os.getenv("SWEEP_SOLVER_OPTION", "0"))
    save_path = os.getenv("SWEEP_SAVE_PATH", "results")
    injection_type = os.getenv("SWEEP_INJECTION_TYPE", "V").upper()
    show_plots = os.getenv("SWEEP_SHOW_PLOTS", "true").lower() in {
        "1",
        "true",
        "yes",
    }

    required_values = {
        "SIMSTUDIO_TOKEN 或 CLOUDPSS_TOKEN": cloudpss_token,
        "CLOUDPSS_MODEL": cloudpss_model,
        "CLOUDPSS_COMPONENT_KEY": component_key,
    }
    missing = [name for name, value in required_values.items() if not value]
    if missing:
        raise RuntimeError(f"缺少必填环境变量: {', '.join(missing)}")
    if injection_type not in {"V", "I"}:
        raise ValueError("SWEEP_INJECTION_TYPE 仅支持 'V' 或 'I'")

    model_parts = cloudpss_model.strip("/").split("/")
    if len(model_parts) != 3 or model_parts[0] != "model":
        raise ValueError("CLOUDPSS_MODEL 必须使用 model/用户名/模型标识 格式")
    _, username, project_key = model_parts

    toolbox = SweepAnalysisToolbox()
    toolbox.set_config(
        cloudpss_token,
        cloudpss_api_url,
        username,
        project_key,
        delete_edges=True,
    )
    toolbox.set_initial_conditions()
    toolbox.create_sweep_canvas()

    target_component = toolbox.project.getComponentByKey(component_key)
    if target_component is None:
        raise ValueError(f"未找到扫频接入元件: {component_key}")
    if tested_pin not in target_component.pins:
        raise ValueError(f"元件 {component_key} 不包含引脚 {tested_pin}")
    voltage_name = "Vm"
    if "WGSource" in target_component.definition:
        # target_component.args["Startup_Time"] = "10000"
        voltage_name = "Vpcc"
    # 配置扫频模块
    if injection_type == "V":

        harmonic_name = "SA扫频模块_V"
        harmonic_args = {
            "Mag": target_component.args[voltage_name] * np.sqrt(2 / 3) * 1000 * 0.03,
            "InitTime": 10,
            "RampTime": 1,
            "Sequence": 1,
            "InitVal1": 5,
            "EndVal1": 100,
            "DeltaStep1": 1,
            "DeltaTime1": 5,
            "InitVal2": 0,
            "EndVal2": 200,
            "DeltaStep2": 5,
            "DeltaTime2": 3,
            "InitVal3": 0,
            "EndVal3": 1000,
            "DeltaStep3": 10,
            "DeltaTime3": 1,
            "RampRatio": 0.2,
            "UnitTest": 0,
        }
    else:
        harmonic_name = "SA扫频模块_I"
        harmonic_args = {
            # "Mag":target_component.args['Pref_WF']/target_component.args['Vpcc']*np.sqrt(2/3)*1000 * 0.03,
            "Mag": 100 / float(target_component.args[voltage_name])  * np.sqrt(2) / 3 * 1000 * 0.03,
            "InitTime": 10,
            "RampTime": 1,
            "Sequence": 1,
            "InitVal1": 10,
            "EndVal1": 40,
            "DeltaStep1": 1,
            "DeltaTime1": 5,
            "InitVal2": 0,
            "EndVal2": 60,
            "DeltaStep2": 5,
            "DeltaTime2": 3,
            "InitVal3": 0,
            "EndVal3": 80,
            "DeltaStep3": 1,
            "DeltaTime3": 2,
            "RampRatio": 0.2,
            "UnitTest": 0}
        # harmonic_args = {
        #     "Mag":target_component.args['Pref_WF']/target_component.args['Vpcc']*np.sqrt(2/3)*1000 * 0.03,
        #     "InitTime": 10,
        #     "RampTime": 1,
        #     "Sequence": 1,
        #     "InitVal1": 11,
        #     "EndVal1": 39,
        #     "DeltaStep1": 2,
        #     "DeltaTime1": 5,
        #     "InitVal2": 0,
        #     "EndVal2": 61,
        #     "DeltaStep2": 10,
        #     "DeltaTime2": 3,
        #     "InitVal3": 0,
        #     "EndVal3": 79,
        #     "DeltaStep3": 2,
        #     "DeltaTime3": 2,
        #     "RampRatio": 0.2,
        #     "UnitTest": 0,
        # }
    component_args = {key: str(value) for key, value in harmonic_args.items()}
    harmonic_pins = {
        "Freq": f"{harmonic_name}.F",
        "Neg": f"{harmonic_name}.Neg",
        "Ph": f"{harmonic_name}.Ph",
        "Phn": f"{harmonic_name}.Phn",
        "Php": f"{harmonic_name}.Php",
        "Pos": target_component.pins[tested_pin],
        "Z": f"{harmonic_name}.Z",
        "Zn": f"{harmonic_name}.Zn",
        "Zp": f"{harmonic_name}.Zp",
    }
    target_component.pins[tested_pin] = harmonic_pins["Neg"]

    harmonic_definition = (
        "model/CloudPSS/Harmonic_continuous_injection_V"
        if injection_type == "V"
        else "model/CloudPSS/Harmonic_continuous_injection_I"
    )
    toolbox.add_comp_in_canvas(
        harmonic_definition,
        canvas=toolbox.c_fid,
        args=component_args,
        pins=harmonic_pins,
        label=harmonic_name,
    )
    toolbox.new_line_position(toolbox.c_fid)

    output_channel_ids = []
    for pin_key, pin_name in harmonic_pins.items():
        if pin_key in {"Pos", "Neg"}:
            continue
        channel_id, _ = toolbox.add_channel(pin_name, 1)
        output_channel_ids.append(channel_id)

    # 设置仿真时间
    time1 = harmonic_args["InitTime"]
    time2 = time1 + ((harmonic_args["EndVal1"] - harmonic_args["InitVal1"]) / harmonic_args["DeltaStep1"] + 1) * harmonic_args["DeltaTime1"]
    time3 = time2 - harmonic_args["DeltaTime2"] + ((harmonic_args["EndVal2"] - harmonic_args["EndVal1"]) / harmonic_args["DeltaStep2"] + 1 ) * harmonic_args["DeltaTime2"]
    end_time = time3 - harmonic_args["DeltaTime3"] + ((harmonic_args["EndVal3"] - harmonic_args["EndVal2"]) / harmonic_args["DeltaStep3"] + 1) * harmonic_args["DeltaTime3"]

    job_name = "Sweep_电磁暂态仿真"
    toolbox.create_job(
        "emtps",
        name=job_name,
        args={
            "begin_time": 0,
            "end_time": end_time,
            "step_time": 0.00005,
            "solver_option": solver_option,
            "n_cpu": n_cpu,
        },
    )
    toolbox.create_config(name="Sweep_参数方案")
    toolbox.add_outputs(
        job_name,
        {
            "0": "频率分析",
            "1": str(sample_freq),
            "2": "compressed",
            "3": 1,
            "4": output_channel_ids,
        },
    )

    runner_id = toolbox.run_project(
        job_name=job_name,
        config_name="Sweep_参数方案",
        show_logs=True,
    )
    if runner_id == -1:
        raise RuntimeError("扫频仿真运行失败")

    # from cloudpss.job.job import Job as cjob

    # Grid_quanyongID = "a6d1a0af-396f-4144-9612-1c984dc323f1"
    # Result1 = cjob.fetch(Grid_quanyongID)
    # import time

    # while Result1.status() < 1:
    #     time.sleep(2)
    # print(Result1.status())


    # simulation_result = Result1.result

    simulation_result = toolbox.runner.result
    result_timestamp = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
    result_dir = Path(save_path or "results") / project_key

    # 绘制原始仿真结果波形图
    toolbox.config["plot_tool"] = "plotly"
    waveform_html_path = result_dir / "simulation_waveform.html"
    toolbox.plot_result(
        simulation_result,
        k=0,
        html_path=waveform_html_path,
        show=show_plots,
        timestamp=result_timestamp,
    )

    # 解析、处理仿真数据
    spectrum_data = toolbox.parse_frequency_spectrum_result(
        simulation_result,
        harmonic_args,
        sample_freq=sample_freq,
    )

    # 保存分析后的仿真结果
    saved_files = toolbox.save_frequency_spectrum_result(
        spectrum_data,
        save_path=save_path,
        project_key=project_key,
        timestamp=result_timestamp,
    )
    saved_files["simulation_waveform"] = toolbox.last_plot_html_path

    # 绘制频谱图和奈奎斯特曲线
    diagnostics = toolbox.read_frequency_spectrum_plot_nyquist_file(
        spectrum_data,
        show=show_plots,
        html_dir=result_dir,
        timestamp=result_timestamp,
    )
    saved_files["analysis_plots"] = diagnostics["html_files"]

    result = {
        "runner_id": str(runner_id),
        "timestamp": result_timestamp,
        "harmonic_args": harmonic_args,
        "spectrum_data": spectrum_data,
        "saved_files": saved_files,
        "resonance_risk": diagnostics["resonance_risk"],
    }
    print(saved_files)
    print("是否有谐振风险:", result["resonance_risk"])
    return result


if __name__ == "__main__":
    main()
