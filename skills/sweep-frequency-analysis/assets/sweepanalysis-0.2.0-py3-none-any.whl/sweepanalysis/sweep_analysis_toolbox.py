"""CloudPSS 扫频分析所需的最小工具集。

本类只保留当前项目实际使用的模型编辑、计算方案配置、结果绘图和
元件定义读取能力，用来替代对 ``CaseEditToolbox``、``PSAToolbox`` 和
``StabilityAnalysis`` 三个大型历史模块的依赖。
"""

from __future__ import annotations

import copy
import json
import os
import re
import time
from collections.abc import Mapping
from pathlib import Path
from string import Template
from typing import Annotated, Any, Callable, Dict, TypeVar

import cloudpss
import matplotlib.pyplot as plt
import numpy as np
import plotly.graph_objects as go
from cloudpss.model.implements.component import Component
from cloudpss.model import Model
from matplotlib.path import Path as MatplotlibPath
from pydantic import Field

_EnvValue = TypeVar("_EnvValue")
_ENVIRONMENT_NAME_PATTERN = re.compile(r"^[A-Z][A-Z0-9_]*$")


def _read_environment_variable(
    name: str,
    default: _EnvValue,
    converter: Callable[[str], _EnvValue] | None = None,
) -> _EnvValue:
    """安全读取并转换环境变量，未设置或空白时返回默认值。"""
    if not isinstance(name, str) or not _ENVIRONMENT_NAME_PATTERN.fullmatch(name):
        raise ValueError(f"非法的环境变量名称: {name!r}")

    raw_value = os.environ.get(name)
    if raw_value is None or not raw_value.strip():
        return default
    if "\x00" in raw_value:
        raise ValueError(f"环境变量 {name} 包含非法的 NUL 字符")

    normalized_value = raw_value.strip()
    if converter is None:
        return normalized_value  # type: ignore[return-value]
    try:
        return converter(normalized_value)
    except (TypeError, ValueError) as error:
        expected_type = getattr(converter, "__name__", str(converter))
        raise ValueError(
            f"环境变量 {name} 无法转换为 {expected_type}: {normalized_value!r}"
        ) from error


SIMSTUDIO_TOKEN = _read_environment_variable("SIMSTUDIO_TOKEN", "")
CLOUDPSS_API_URL = _read_environment_variable(
    "CLOUDPSS_API_URL", "https://cloudpss.net/"
)
DEFAULT_POSITION_VALUE = _read_environment_variable(
    "CET_DEFAULT_POSITION_VALUE", 20, int
)
OUTPUT_CANVAS_MAX_X = _read_environment_variable(
    "PSAT_OUTPUT_CANVAS_MAX_X", 500, int
)

if DEFAULT_POSITION_VALUE < 0:
    raise ValueError("环境变量 CET_DEFAULT_POSITION_VALUE 不能小于 0")
if OUTPUT_CANVAS_MAX_X <= 0:
    raise ValueError("环境变量 PSAT_OUTPUT_CANVAS_MAX_X 必须大于 0")


class SweepAnalysisToolbox:
    """当前扫频流程使用的 CloudPSS 模型编辑工具。"""

    def __init__(self) -> None:
        """初始化新版 CloudPSS 扫频工具状态。"""
        self.config = {
            "token": SIMSTUDIO_TOKEN,
            "api_url": CLOUDPSS_API_URL,
            "model": "test",
            "username": "admin",
            "plot_tool": "plotly",
            "delete_edges": False,
        }
        self.project: Model = None
        self.runner: Any = None
        self.topo: dict[str, Any] | None = None
        self.pos: dict[str, dict[str, float]] = {}
        self.channel_pin_dict: dict[str, str] = {}
        self.current_canvas: str | None = None
        self.last_plot_html_path: str | None = None

        self.c_fid = "canvas_sweep"
        self.c_oid = "canvas_AutoSA_ExtraOutput"

        self._init_job_templates()

        if self.config["token"]:
            cloudpss.setToken(self.config["token"])
        if self.config["api_url"]:
            os.environ["CLOUDPSS_API_URL"] = self.config["api_url"]

    def _init_job_templates(self) -> None:
        """初始化新版 CloudPSS 计算方案与参数方案模板。"""
        self.emtp_job_init = {
            "args": {
                "begin_time": 0,
                "debug": 0,
                "end_time": 10,
                "initial_type": 0,
                "load_snapshot": 0,
                "load_snapshot_name": "",
                "max_initial_time": 1,
                "mergeBusNode": 0,
                "n_cpu": 16,
                "output_channels": [],
                "ramping_time": 0,
                "save_snapshot": 0,
                "save_snapshot_name": "snapshot",
                "save_snapshot_time": 1,
                "solver": 0,
                "solver_option": 7,
                "step_time": 0.0001,
                "task_cmd": "",
                "task_queue": "taskManager",
            },
            "name": "CA电磁暂态仿真方案",
            "rid": "job-definition/cloudpss/emtp",
        }
        self.pf_job_init = {
            "args": {
                "@debug": "",
                "@priority": 0,
                "@queue": 1,
                "@tres": "cpu=1",
                "CheckInput": 1,
                "MaxIteration": 30,
                "ShowRunLog": 2,
                "SkipPF": 0,
                "UseBusAngleAsInit": 1,
                "UseBusVoltageAsInit": 1,
                "UseReactivePowerLimit": 1,
                "UseVoltageLimit": 1,
            },
            "name": "CA潮流计算方案",
            "rid": "function/CloudPSS/power-flow",
        }
        self.emtps_job_init = {
            "args": {
                "@debug": "",
                "@priority": 0,
                "@queue": 1,
                "@tres": "cpu=1",
                "begin_time": 0,
                "comm": [],
                "comm_freq": 1,
                "comm_protocol": 0,
                "comm_type": 0,
                "ctrlparallel_option": 0,
                "debug": 0,
                "dev_id": 1,
                "dev_num": 1,
                "end_time": 15,
                "event_option": 0,
                "init_cfg": 0,
                "initial_type": 0,
                "kernel_option": 1,
                "load_snapshot": "0",
                "load_snapshot_name": "",
                "max_initial_time": 1,
                "mergeBusNode": 0,
                "multi_dev_partition": [],
                "n_cpu": 1,
                "n_ele_cpu": 1,
                "only_partition": 0,
                "output_channels": [],
                "partition_info": [
                    {"0": 0, "1": "", "2": "", "ɵid": 25021700}
                ],
                "partition_msg_output": 1,
                "partition_option": 0,
                "ramping_time": 0,
                "realtime_timeout": 10,
                "save_snapshot": 0,
                "save_snapshot_name": "snapshot",
                "save_snapshot_time": 1,
                "sim_option": 0,
                "snapshot_cfg": 0,
                "solver": 0,
                "solver_option": 0,
                "step_time": 0.00001,
                "task_cmd": "",
            },
            "name": "CA电磁暂态仿真方案_新",
            "rid": "function/CloudPSS/emtps",
        }
        self.project_config_init = {"args": {}, "name": "CA参数方案", "pins": {}}

    def set_config(
        self,
        token: Annotated[str, Field(description="从 cloudpss 平台中申请的 token。")] = None,
        api_url: Annotated[str, Field(description="API 域名地址。")] = None,
        username: Annotated[str, Field(description="用户名。")] = None,
        model: Annotated[str, Field(description="算例名称（不带/model/username）。")] = None,
        delete_edges: Annotated[bool, Field(description="是否将所有的连接线都删除，统一使用引脚管理连接关系")] = None,
    ) -> None:
        """更新 CloudPSS 连接配置和模型编辑选项。

        只更新调用时显式提供的字段；未提供的参数保留当前配置。设置
        ``token`` 或 ``api_url`` 后会同步更新 CloudPSS SDK 和进程环境变量。

        Returns:
            None。配置会直接写入当前工具实例的 ``config`` 属性。

        Raises:
            ValueError: 字符串配置为空或不是字符串时抛出。
            TypeError: ``delete_edges`` 不是布尔值或 ``None`` 时抛出。
        """
        string_values = {
            "token": token,
            "api_url": api_url,
            "username": username,
            "model": model,
        }
        for name, value in string_values.items():
            if value is not None and (not isinstance(value, str) or not value):
                raise ValueError(f"{name} 参数必须是非空字符串或 None")


        if delete_edges is not None and not isinstance(delete_edges, bool):
            raise TypeError("delete_edges 参数必须是布尔类型或 None")

        updates = {
            "token": token,
            "api_url": api_url,
            "username": username,
            "model": model,
            "delete_edges": delete_edges,
        }
        self.config.update({key: value for key, value in updates.items() if value is not None})

        if token is not None:
            cloudpss.setToken(token)
        if api_url is not None:
            os.environ["CLOUDPSS_API_URL"] = api_url

    def set_initial_conditions(self) -> None:
        """校验运行配置并获取模型，初始化后续编辑所需的运行状态。

        方法会根据当前配置获取 CloudPSS 模型，建立输出通道索引，并为
        当前画布初始化元件布局坐标；当 ``delete_edges`` 开启时，还会先
        刷新拓扑并将图形连接线转换为命名引脚连接。

        Returns:
            None。获取的模型和索引分别保存到 ``project``、
            ``channel_pin_dict`` 和画布状态属性中。

        Raises:
            RuntimeError: 必需配置缺失，或 CloudPSS 模型/拓扑初始化失败时抛出。
        """
        missing = [
            name
            for name in ("token", "api_url", "username", "model")
            if not self.config.get(name)
        ]
        if missing:
            raise RuntimeError(f"CloudPSS 运行配置缺失: {', '.join(missing)}")

        cloudpss.setToken(self.config["token"])
        os.environ["CLOUDPSS_API_URL"] = self.config["api_url"]
        model_rid = f'model/{self.config["username"]}/{self.config["model"]}'
        print("正在获取算例...")
        self.project = cloudpss.Model.fetch(model_rid)



        if self.config["delete_edges"]:
            self._refresh_topology()
            self._delete_edges()

        self._set_channel_pin_dict()

        canvases = self.project.revision.implements.diagram.canvas
        if canvases:
            self.current_canvas = canvases[0]["key"]
            self._init_canvas_position(self.current_canvas)
        else:
            self.current_canvas = None

    def _refresh_topology(self) -> dict[str, Any]:
        """根据当前模型 revision 和参数方案重新获取 EMTP 拓扑。"""
        if self.project is None:
            raise RuntimeError("项目尚未初始化，请先调用 set_initial_conditions()")
        if not getattr(self.project, "revision", None):
            raise RuntimeError("当前项目缺少 revision")

        try:
            current_config = self.project.context["currentConfig"]
            config = self.project.configs[current_config]
        except (AttributeError, KeyError, IndexError, TypeError) as error:
            raise RuntimeError("无法获取当前参数方案") from error

        revision = cloudpss.ModelRevision.create(self.project.revision)
        if not isinstance(revision, dict) or not revision.get("hash"):
            raise RuntimeError("创建模型 revision 失败：返回结果中缺少 hash")

        topology = cloudpss.ModelTopology.fetch(
            revision["hash"],
            "emtp",
            config,
            maximumDepth=0,
        )
        self.topo = topology.toJSON()
        return self.topo

    def _get_edge_topology_pin_number(
        self, cid: str, _visited: set[str] | None = None
    ) -> str:
        """递归查找图形边连接的拓扑引脚编号。"""

        visited = set() if _visited is None else _visited
        if cid in visited:
            raise RuntimeError(f"检测到边的循环引用: {cid}")
        visited.add(cid)

        edge = self.project.getComponentByKey(cid)
        if edge is None or getattr(edge, "shape", None) != "diagram-edge":
            raise ValueError(f"元件 '{cid}' 不是有效的 diagram-edge")

        for endpoint in (edge.source, edge.target):
            if not isinstance(endpoint, dict) or "cell" not in endpoint:
                continue

            component_id = endpoint["cell"]
            if "port" not in endpoint:
                return self._get_edge_topology_pin_number(component_id, visited)

            topology_component = self.topo["components"].get(f"/{component_id}")
            if topology_component is None:
                return "0"
            return str(topology_component.get("pins", {}).get(endpoint["port"], "0"))

        return "0"

    def _delete_edges(self) -> int:
        """将图形边转换为命名引脚连接并删除所有 ``diagram-edge``。"""

        topology_components = self.topo.get("components")
        mappings = self.topo.get("mappings", {})
        if not isinstance(topology_components, dict):
            raise RuntimeError("拓扑数据缺少 components")
        input_mappings = mappings.get("in", {})
        output_mappings = mappings.get("out", {})

        self.topology_pin_name_dict: dict[int, list[Any]] = {}
        for topology_id, topology_component in topology_components.items():
            component_id = topology_id.removeprefix("/")
            component = self.project.getComponentByKey(component_id)

            for port, topology_pin in topology_component.get("pins", {}).items():
                if topology_pin in (None, ""):
                    continue
                pin_number = int(topology_pin)
                pin_names = self.topology_pin_name_dict.setdefault(pin_number, [])
                pin_name = component.pins.get(port, "")
                if pin_name not in (None, "") and pin_name not in pin_names:
                    pin_names.append(pin_name)

            for argument, mapping_key in topology_component.get("args", {}).items():
                mapping_key_text = str(mapping_key)
                if mapping_key_text in input_mappings:
                    mapped_pin = input_mappings[mapping_key_text]
                elif mapping_key_text in output_mappings:
                    mapped_pin = output_mappings[mapping_key_text]
                else:
                    continue

                pin_number = int(mapped_pin)
                pin_names = self.topology_pin_name_dict.setdefault(pin_number, [])
                argument_value = component.args.get(argument, "")
                if isinstance(argument_value, dict):
                    argument_value = argument_value.get("source", "")
                if argument_value not in (None, "") and argument_value not in pin_names:
                    pin_names.append(argument_value)

        automatic_prefix = f'AutoAddPin{time.strftime("%Y%m%d%H%M%S")}_'
        automatic_index = 0
        for pin_names in self.topology_pin_name_dict.values():
            if not pin_names:
                pin_names.append(f"{automatic_prefix}{automatic_index}")
                automatic_index += 1

        edges_by_pin: dict[int, list[str]] = {}
        for component_id, component in list(self.project.getAllComponents().items()):
            if component.shape != "diagram-edge":
                continue
            topology_pin = int(self._get_edge_topology_pin_number(component_id))
            edges_by_pin.setdefault(topology_pin, []).append(component_id)

        deleted_count = 0
        cells = self.project.revision.implements.diagram.cells
        for topology_pin, edge_ids in edges_by_pin.items():
            pin_names = self.topology_pin_name_dict.get(topology_pin)
            if not pin_names:
                pin_names = [f"{automatic_prefix}{automatic_index}"]
                self.topology_pin_name_dict[topology_pin] = pin_names
                automatic_index += 1
            pin_name = pin_names[0]

            for edge_id in edge_ids:
                edge = self.project.getComponentByKey(edge_id)
                for endpoint in (edge.source, edge.target):
                    if not isinstance(endpoint, dict):
                        continue
                    if "cell" not in endpoint or "port" not in endpoint:
                        continue
                    endpoint_component = self.project.getComponentByKey(endpoint["cell"])
                    if endpoint_component.pins.get(endpoint["port"], "") == "":
                        endpoint_component.pins[endpoint["port"]] = pin_name
                cells.pop(edge_id, None)
                deleted_count += 1

        return deleted_count

    def _set_channel_pin_dict(self) -> None:
        """建立输出引脚到通道元件 key 的索引。"""
        self.channel_pin_dict = {}
        channels = self.project.getComponentsByRid("model/CloudPSS/_newChannel")
        for key in channels:
            component = self.project.getComponentByKey(key)
            self.channel_pin_dict[str(component.pins["0"])] = key

    def _init_canvas_position(self, canvas: str) -> None:
        """初始化指定画布的元件布局坐标。"""
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")

        self.pos[canvas] = {
            "dx": DEFAULT_POSITION_VALUE,
            "dy": DEFAULT_POSITION_VALUE,
            "x0": DEFAULT_POSITION_VALUE,
            "y0": DEFAULT_POSITION_VALUE,
            "x": DEFAULT_POSITION_VALUE,
            "y": DEFAULT_POSITION_VALUE,
            "maxdy": 0,
        }

    def create_canvas(
        self,
        canvas: Annotated[str, Field(description="图纸的key")],
        name: Annotated[str, Field(description="图纸的名称")]
    ) -> None:
        """在当前模型中创建画布并初始化其元件布局坐标。

        Returns:
            None。新画布会追加到模型 revision 的画布列表中。

        Raises:
            ValueError: ``canvas`` 或 ``name`` 不是非空字符串时抛出。
            RuntimeError: 当前工具尚未通过 :meth:`set_initial_conditions` 获取模型时抛出。
        """
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")
        if not isinstance(name, str) or not name:
            raise ValueError("name 参数必须是非空字符串")

        self.project.revision.implements.diagram.canvas.append({"key": canvas, "name": name})
        self._init_canvas_position(canvas)

    def create_sweep_canvas(self) -> None:
        """确保扫频流程所需的模块画布和输出画布存在。

        已存在的画布只会重新初始化布局坐标，不会重复创建。该方法不
        负责添加元件或提交模型，调用方可在其后使用
        :meth:`add_comp_in_canvas` 和 :meth:`add_channel` 完成布置。

        Returns:
            None。画布状态会更新到当前模型和 ``pos`` 属性。

        Raises:
            RuntimeError: 当前工具尚未初始化 CloudPSS 模型时抛出。
        """
        existing = {
            canvas["key"] for canvas in self.project.revision.implements.diagram.canvas
        }
        for canvas, name in (
            (self.c_fid, "扫频模块相关设置"),
            (self.c_oid, "扫频分析所需输出通道"),
        ):
            if canvas not in existing:
                self.create_canvas(canvas, name)
            else:
                self._init_canvas_position(canvas)

    def _add_x_position(
        self, canvas: str, max_x: float | None = None
    ) -> None:
        """根据元件尺寸推进画布横坐标，并在超过限制时换行。"""


        self.pos[canvas]["x"] += 200
        self.pos[canvas]["maxdy"] = max(
            self.pos[canvas]["maxdy"], 300
        )
        if max_x is not None and self.pos[canvas]["x"] > max_x:
            self.new_line_position(canvas)

    def new_line_position(
        self,
        canvas: Annotated[str, Field(description="当前图纸的key")]
    ) -> None:
        """将指定画布的下一个元件位置移动到新行起点。

        Returns:
            None。指定画布的 ``x``、``y`` 和行高状态会被更新。

        Raises:
            ValueError: ``canvas`` 为空，或尚未调用画布初始化方法时抛出。
        """
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")
        if canvas not in self.pos:
            raise ValueError(f"canvas '{canvas}' 未在 pos 字典中初始化")

        self.pos[canvas]["x"] = self.pos[canvas]["x0"]
        self.pos[canvas]["y"] += self.pos[canvas]["dy"] + self.pos[canvas]["maxdy"]
        self.pos[canvas]["maxdy"] = 0

    def add_comp_in_canvas(
        self,
        definition: Annotated[str, Field(description="元件的RID")],
        canvas: Annotated[str, Field(description="元件所在的画布")],
        args: Annotated[dict, Field(description="元件的参数")] = None,
        pins: Annotated[dict, Field(description="元件的引脚")] = None,
        label: Annotated[str, Field(description="元件的标签")] = None,
        d_x: Annotated[int, Field(description="元件之间的x轴间距")] = 10,
        max_x: Annotated[float, Field(description="换行参数，图纸中一行元件的最大宽度")] = None
    ) -> tuple[str, str]:
        """在指定画布中新增元件，并推进自动布局位置。

        元件的标识由 CloudPSS 平台生成，调用方只需通过 ``label`` 提供
        显示标签。方法会按当前画布坐标添加元件，再根据 ``d_x`` 和
        ``max_x`` 更新后续元件的位置。

        Returns:
            ``(component_id, label)`` 元组，分别为平台生成的元件 ID 和
            本次添加使用的标签。

        Raises:
            KeyError: ``canvas`` 尚未初始化布局坐标时抛出。
            RuntimeError: 当前工具尚未初始化 CloudPSS 模型时抛出。
            ValueError: 元件定义或画布参数不被 CloudPSS 模型接受时，底层
                SDK 可能抛出该异常。
        """
        position = {name: self.pos[canvas][name] for name in ("x", "y")}
        component_args = args.copy() if args is not None else {}

        comp_rs = self.project.addComponent(
            definition, label, component_args, pins, canvas, position
        )
        self._add_x_position(canvas, max_x)
        self.pos[canvas]["x"] += d_x
        return comp_rs.id, label

    def add_channel(
        self,
        pin_name: Annotated[str, Field(description="要添加输出通道的引脚名")],
        dim: Annotated[int, Field(description="输出通道的维度")],
        channel_name: Annotated[str, Field(description="输出通道的名称")] = None,
    ) -> tuple[str, str]:
        """为指定引脚新增或复用一个 CloudPSS 输出通道。

        如果该引脚已经建立通道，则复用已有元件，并在提供
        ``channel_name`` 时同步更新其名称；否则在扫频输出画布中创建新
        通道元件。

        Returns:
            ``(component_id, label)`` 元组，分别为输出通道元件 ID 和标签。

        Raises:
            KeyError: 输出画布尚未初始化，或已有通道元件缺少预期属性时抛出。
            RuntimeError: 当前工具尚未初始化模型/通道索引时抛出。
        """

        if pin_name not in self.channel_pin_dict:
            component_label = pin_name if channel_name is None else channel_name
            component_id, label = self.add_comp_in_canvas(
                "model/CloudPSS/_newChannel",
                canvas=self.c_oid,
                args={"Name": component_label, "Dim": dim},
                pins={"0": pin_name},
                label=component_label,
                max_x=OUTPUT_CANVAS_MAX_X,
            )
            self.channel_pin_dict[pin_name] = component_id
            return component_id, label

        component = self.project.getComponentByKey(self.channel_pin_dict[pin_name])
        if channel_name is not None:
            component.args["Name"] = channel_name
            component.label = channel_name
        return component.id, component.label

    def create_job(
        self,
        stype: Annotated[str, Field(description="计算方案的类型，'emtps'表示电磁暂态仿真，'power-flow'表示潮流计算")] = 'emtps',
        name: Annotated[str, Field(description="计算方案的名称")] = None,
        args: Annotated[Dict, Field(description="计算方案的配置。仅支持使用原始参数 key 进行增量更新")] = None,
    ) -> None:
        """根据内置模板创建一个 CloudPSS 计算方案。

        ``args`` 采用原始参数 key 进行增量更新，不会修改内置模板本身。
        支持 ``emtp``、``emtps``、``power-flow`` 和兼容别名
        ``powerFlow`` 四种方案类型。

        Returns:
            None。新方案会添加到当前模型的计算方案列表中。

        Raises:
            ValueError: ``stype`` 不在支持的方案类型中时抛出。
            RuntimeError: 当前工具尚未初始化 CloudPSS 模型时，底层模型操作
                可能抛出该异常。
        """
        templates = {
            "emtp": self.emtp_job_init,
            "emtps": self.emtps_job_init,
            "power-flow": self.pf_job_init,
            "powerFlow": self.pf_job_init,
        }
        if stype not in templates:
            raise ValueError(f"不支持的计算方案类型: {stype}")
        job = copy.deepcopy(templates[stype])
        if name is not None:
            job["name"] = name
        if args:
            job["args"].update(args)
        self.project.addJob(job)

    def create_config(
        self,
        name: Annotated[str, Field(description="参数方案名称")] = None,
        args: Annotated[Dict, Field(description="参数方案的配置。可以不填全，填需要更新的参数即可")] = None,
        pins: Annotated[Dict, Field(description="引脚配置")] = None,
    ) -> None:
        """根据默认模板创建一个模型参数方案。

        ``args`` 和 ``pins`` 均支持只提供需要覆盖的字段；未提供的字段
        保留为空或使用默认方案模板中的值。

        Returns:
            None。新参数方案会添加到当前模型的参数方案列表中。

        Raises:
            RuntimeError: 当前工具尚未初始化 CloudPSS 模型时，底层模型操作
                可能抛出该异常。
        """

        config = copy.deepcopy(self.project_config_init)
        if name is not None:
            config["name"] = name
        if args is not None:
            config["args"].update(args)
        if pins is not None:
            config["pins"].update(pins)
        self.project.addConfig(config)

    def add_outputs(
        self,
        job_name: Annotated[str, Field(description="计算方案的名称")],
        channels: Annotated[Dict, Field(description="需要配置的输出通道，格式为：[输出图像名称, 输出频率, 输出图像类型, 图像宽度, 输出通道key]。")],
    ) -> int:
        """向 EMTP 或 EMTPS 计算方案追加一组输出通道配置。

        ``channels`` 应符合 CloudPSS 计算方案要求的输出通道结构；方法
        不会替换该方案已有配置。

        Returns:
            新增输出通道在方案 ``output_channels`` 列表中的零基索引。

        Raises:
            ValueError: 找不到指定计算方案，或方案不是 EMTP/EMTPS 类型时抛出。
            RuntimeError: 当前工具尚未初始化 CloudPSS 模型时，底层模型操作
                可能抛出该异常。
        """

        jobs = self.project.getModelJob(job_name)
        if not jobs:
            raise ValueError(f"未找到名为 '{job_name}' 的计算方案")
        job = jobs[0]
        supported_rids = {self.emtp_job_init["rid"], self.emtps_job_init["rid"]}
        if job["rid"] not in supported_rids:
            raise ValueError(f"计算方案 '{job_name}' 不是 EMTP 或 EMTPS 类型")
        job["args"]["output_channels"].append(channels)
        return len(job["args"]["output_channels"]) - 1

    def run_project(
        self,
        job_name: Annotated[str, Field(description="计算方案名称")],
        config_name: Annotated[str, Field(description="参数方案名称")],
        show_logs: Annotated[bool, Field(description="是否显示日志")] = False,
        api_url: Annotated[str, Field(description="API的URL")] = None,
        websocket_error_time: Annotated[float, Field(description="WebSocket错误时间")] = None,
    ) -> str | int:
        """运行指定计算方案并等待 CloudPSS 运行器结束。

        对电磁暂态仿真会根据结果时间输出进度；当 WebSocket 临时异常且
        ``websocket_error_time`` 允许重试时，会自动重新提交一次运行。

        Returns:
            成功完成时返回 CloudPSS runner ID；无法继续运行且平台报告失败
            时返回 ``-1``。

        Raises:
            ValueError: 找不到指定的计算方案或参数方案时抛出。
            RuntimeError: 多次启动失败，或 CloudPSS 返回不可恢复的运行错误时抛出。
        """


        jobs = self.project.getModelJob(job_name)
        if not jobs:
            raise ValueError(f"未找到名为 '{job_name}' 的计算方案")
        configs = self.project.getModelConfig(config_name)
        if not configs:
            raise ValueError(f"未找到名为 '{config_name}' 的参数方案")

        job = jobs[0]
        config = configs[0]
        for attempt in range(5):
            try:
                run_options = {"job": job, "config": config}
                if api_url is not None:
                    run_options["apiUrl"] = api_url
                self.runner = self.project.run(**run_options)
                break
            except Exception as error:
                if not isinstance(
                    error, (ConnectionError, TimeoutError, OSError, RuntimeError)
                ):
                    raise
                if attempt == 4:
                    raise RuntimeError("启动仿真失败，已重试 5 次") from error
                print(f"Start runner failed, restarting...{error}")
                time.sleep(60)

        simulation_rids = {self.emtp_job_init["rid"], self.emtps_job_init["rid"]}
        is_transient_simulation = job["rid"] in simulation_rids
        end_time = (
            float(job["args"]["end_time"])
            if is_transient_simulation
            else None
        )
        start_time = time.time()

        while True:
            status = self.runner.status()
            if status >= 1:
                return self.runner.id
            if status == -1:
                print("仿真出错了，可能是 WebSocket 问题。")
                if websocket_error_time is not None and is_transient_simulation:
                    try:
                        current_time = self._get_result_end_time()
                    except (IndexError, KeyError, TypeError, ValueError):
                        current_time = None
                    should_retry = (
                        current_time is None
                        or current_time < end_time - websocket_error_time
                    )
                    if should_retry:
                        current_text = (
                            "None" if current_time is None else str(round(current_time, 2))
                        )
                        print(f"准备重新运行仿真。Current Time：{current_text}")
                        time.sleep(15)
                        return self.run_project(
                            job_name,
                            config_name,
                            show_logs,
                            api_url,
                            websocket_error_time,
                        )
                return -1

            if show_logs:
                for log in self.get_runner_logs():
                    content = log.get("data", {}).get("content")
                    if content is not None:
                        print(content)

            elapsed = time.time() - start_time
            if is_transient_simulation:
                try:
                    current_time = self._get_result_end_time()
                except (IndexError, KeyError, TypeError, ValueError):
                    current_time = None
            else:
                current_time = None
            if current_time is not None:
                progress = current_time / end_time * 100 if end_time > 0 else 0
                print(
                    f"Progress: {round(current_time, 2)}s / {end_time}s "
                    f"({progress:.1f}%). Time cost: {elapsed:.1f}s. "
                    f"Runner Status: {status}"
                )
                if round(current_time, 2) >= end_time:
                    return self.runner.id
            else:
                print(f"Time cost: {elapsed:.1f}s. Runner Status: {status}")
            time.sleep(10)

    def _get_result_end_time(self) -> float | None:
        """返回第一张结果图当前的最后时刻；结果尚未生成时返回 ``None``。"""
        channel_names = self.runner.result.getPlotChannelNames(0)
        if not channel_names:
            return None
        data = self.runner.result.getPlotChannelData(0, channel_names[0])
        x_values = data.get("x", [])
        return float(x_values[-1]) if x_values else None

    @staticmethod
    def _timestamped_file_path(
        path: str | os.PathLike[str], timestamp: str | None = None
    ) -> Path:
        """为输出文件名添加时间戳，并避免同名文件被覆盖。"""
        output_path = Path(path)
        timestamp_text = timestamp or time.strftime("%Y_%m_%d_%H_%M_%S")
        timestamp_pattern = re.compile(
            rf"_{re.escape(timestamp_text)}(?:_\d+)?$"
        )
        if not timestamp_pattern.search(output_path.stem):
            output_path = output_path.with_name(
                f"{output_path.stem}_{timestamp_text}{output_path.suffix}"
            )

        candidate = output_path
        index = 1
        while candidate.exists():
            candidate = output_path.with_name(
                f"{output_path.stem}_{index}{output_path.suffix}"
            )
            index += 1
        return candidate

    def get_runner_logs(self) -> list[dict[str, Any]]:
        """读取当前运行器产生的日志。

        Returns:
            日志记录字典列表；运行器尚未创建时返回空列表。

        Raises:
            RuntimeError: 运行器已创建但 CloudPSS 结果服务不可用时，底层 SDK
                可能抛出该异常。
        """
        runner = getattr(self, "runner", None)
        if runner is None:
            return []
        return runner.result.getLogs()

    def plot_result(
        self,
        result: Annotated[
            Any, Field(description="CloudPSS 原始仿真结果对象、结果 ID 或当前 runner")
        ] = None,
        k: Annotated[int | None, Field(description="要绘制的结果图索引")] = None,
        html_path: Annotated[
            str | os.PathLike[str] | None,
            Field(description="Plotly HTML 输出路径；为 None 时不保存"),
        ] = None,
        show: Annotated[
            bool, Field(description="是否显示图形；批处理时可设为 False")
        ] = True,
        timestamp: Annotated[
            str | None,
            Field(description="保存文件使用的统一时间戳；未指定时自动生成"),
        ] = None,
    ) -> Any:
        """绘制原始仿真结果波形，并可保存为独立的 Plotly HTML 文件。

        该方法只负责 CloudPSS 返回的原始时域波形；频谱、阻尼系数和
        奈奎斯特图由 ``read_frequency_spectrum_plot_nyquist_file`` 负责。
        未提供 ``result`` 时使用当前 runner 的结果；Plotly 模式下提供
        ``html_path`` 可指定 HTML 文件的基础路径；实际文件名会自动追加
        ``timestamp`` 时间戳。对同一仿真流程，应将同一个 ``timestamp``
        传给所有结果保存方法，以保持文件名一致。

        Returns:
            Plotly 模式返回 ``plotly.graph_objects.Figure``；Matplotlib
            模式返回 ``matplotlib.axes.Axes``。

        Raises:
            TypeError: ``show`` 不是布尔值时抛出。
            ValueError: 图索引无效、结果 ID 为空或绘图工具不受支持时抛出。
            RuntimeError: 未提供结果且 runner 尚未初始化，或指定结果尚未
                成功完成时抛出。
        """
        if not isinstance(show, bool):
            raise TypeError("show 参数必须是布尔类型")
        if k is not None and (not isinstance(k, int) or isinstance(k, bool) or k < 0):
            raise ValueError("k 参数必须是非负整数或 None")

        if result is None:
            runner = getattr(self, "runner", None)
            if runner is None:
                raise RuntimeError("Runner 未初始化，且未提供仿真结果")
            result = runner.result
        elif isinstance(result, str):
            if not result:
                raise ValueError("结果 ID 不能为空字符串")
            from cloudpss.job.job import Job

            result_job = Job.fetch(result)
            if result_job.status() != 1:
                raise RuntimeError(
                    f"仿真结果尚未成功完成，当前状态={result_job.status()}"
                )
            result = result_job.result

        plot_index = 0 if k is None else k
        channel_names = result.getPlotChannelNames(plot_index)

        if self.config["plot_tool"] == "plotly":
            figure = go.Figure()
            for channel_name in channel_names:
                data = result.getPlotChannelData(plot_index, channel_name)
                figure.add_trace(
                    go.Scatter(x=data["x"], y=data["y"], mode="lines", name=channel_name)
                )
            figure.update_layout(
                title=result.getPlot(plot_index)["data"]["title"],
                xaxis_title="Time / s",
                yaxis_title="Value",
            )
            if html_path is not None:
                output_path = self._timestamped_file_path(html_path, timestamp)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                figure.write_html(str(output_path), include_plotlyjs=True)
                self.last_plot_html_path = str(output_path)
            if show:
                figure.show()
            return figure

        if self.config["plot_tool"] == "matplotlib":
            figure, axes = plt.subplots(figsize=(6, 3))
            axes.set_title(result.getPlot(plot_index)["data"]["title"])
            for channel_name in channel_names:
                data = result.getPlotChannelData(plot_index, channel_name)
                axes.plot(data["x"], data["y"], label=channel_name)
            axes.set_xlabel("Time / s")
            axes.set_ylabel("Value")
            axes.legend()
            if show:
                plt.show()
            return axes

        raise ValueError(f"不支持的绘图工具: {self.config['plot_tool']}")

    def parse_frequency_spectrum_result(
        self,
        simulation_result: Annotated[
            Any, Field(description="CloudPSS 扫频仿真结果对象")
        ],
        harmonic_args: Annotated[
            Mapping[str, float], Field(description="扫频元件的分段频率和持续时间参数")
        ],
        sample_freq: Annotated[
            float, Field(description="仿真结果的实际输出采样频率，单位为 Hz")
        ] = 100,
    ) -> dict[str, list[Any]]:
        """从扫频仿真结果中解析频率、阻抗幅值和相位。

        根据三段扫频参数定位每个频率点的稳态采样窗口，对正序、负序和
        综合阻抗及相位通道求平均，生成可保存和绘图的频谱数据。

        Returns:
            包含频率 ``F``、阻抗幅值 ``Z`` 和相位 ``Ph`` 的字典。

        Raises:
            ValueError: 采样频率无效、输出通道缺失或结果样本数量不足。
        """
        if sample_freq <= 0:
            raise ValueError("sample_freq 必须大于 0")

        point_counts = (
            round(
                (harmonic_args["EndVal1"] - harmonic_args["InitVal1"])
                / harmonic_args["DeltaStep1"]
            )
            + 1,
            round(
                (harmonic_args["EndVal2"] - harmonic_args["EndVal1"])
                / harmonic_args["DeltaStep2"]
            ),
            round(
                (harmonic_args["EndVal3"] - harmonic_args["EndVal2"])
                / harmonic_args["DeltaStep3"]
            ),
        )
        point_count = sum(point_counts)
        frequency = np.zeros(point_count)
        impedance = np.zeros((point_count, 3))
        phase = np.zeros((point_count, 3))

        time1 = harmonic_args["InitTime"]
        time2 = time1 + (
            (harmonic_args["EndVal1"] - harmonic_args["InitVal1"])
            / harmonic_args["DeltaStep1"]
            + 1
        ) * harmonic_args["DeltaTime1"]
        time3 = time2 - harmonic_args["DeltaTime2"] + (
            (harmonic_args["EndVal2"] - harmonic_args["EndVal1"])
            / harmonic_args["DeltaStep2"]
            + 1
        ) * harmonic_args["DeltaTime2"]

        plot_index = 0
        output_channels: dict[str, str] = {}
        for channel_name in simulation_result.getPlotChannelNames(plot_index):
            if "Zn" in channel_name:
                output_channels["Zn"] = channel_name
            elif "Zp" in channel_name:
                output_channels["Zp"] = channel_name
            elif "Z" in channel_name:
                output_channels["Z"] = channel_name
            elif "Php" in channel_name:
                output_channels["Php"] = channel_name
            elif "Phn" in channel_name:
                output_channels["Phn"] = channel_name
            elif "Ph" in channel_name:
                output_channels["Ph"] = channel_name
            elif "F" in channel_name:
                output_channels["Freq"] = channel_name

        required_channels = {"Freq", "Z", "Zn", "Zp", "Ph", "Phn", "Php"}
        missing_channels = sorted(required_channels - output_channels.keys())
        if missing_channels:
            raise ValueError(f"仿真结果缺少输出通道: {', '.join(missing_channels)}")

        frequency_values = np.asarray(
            simulation_result.getPlotChannelData(
                plot_index, output_channels["Freq"]
            )["y"]
        )
        impedance_values = [
            np.asarray(
                simulation_result.getPlotChannelData(
                    plot_index, output_channels[name]
                )["y"]
            )
            for name in ("Z", "Zn", "Zp")
        ]
        phase_values = [
            np.asarray(
                simulation_result.getPlotChannelData(
                    plot_index, output_channels[name]
                )["y"]
            )
            for name in ("Ph", "Phn", "Php")
        ]
        available_samples = min(
            len(frequency_values),
            *(len(values) for values in impedance_values),
            *(len(values) for values in phase_values),
        )

        segment_starts = (time1, time2, time3)
        segment_durations = (
            harmonic_args["DeltaTime1"],
            harmonic_args["DeltaTime2"],
            harmonic_args["DeltaTime3"],
        )
        offset = 0
        average_rate = 0.1
        for count, start_time, duration in zip(
            point_counts, segment_starts, segment_durations
        ):
            position = round(sample_freq * start_time)
            step = round(sample_freq * duration)
            window_size = round(average_rate * step)
            if step <= 0 or window_size <= 0:
                raise ValueError("采样频率过低，无法为扫频点生成有效的平均窗口")

            for point_index in range(count):
                end = position + step * (point_index + 1) - 1
                start = end - window_size
                if start < 0 or end > available_samples:
                    raise ValueError("仿真结果长度不足，无法解析全部扫频点")

                result_index = offset + point_index
                frequency[result_index] = np.mean(frequency_values[start:end])
                for sequence_index in range(3):
                    impedance[result_index, sequence_index] = np.mean(
                        impedance_values[sequence_index][start:end]
                    )
                    phase[result_index, sequence_index] = np.mean(
                        phase_values[sequence_index][start:end]
                    )
            offset += count

        return {
            "F": frequency.tolist(),
            "Z": impedance.tolist(),
            "Ph": phase.tolist(),
        }

    @staticmethod
    def _normalize_frequency_spectrum_data(
        spectrum_data: Annotated[
            Mapping[str, Any], Field(description="包含 F、Z 和 Ph 字段的频谱数据")
        ],
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """校验频谱数据，并统一转换为 NumPy 数组。"""
        missing_keys = {"F", "Z", "Ph"} - spectrum_data.keys()
        if missing_keys:
            raise ValueError(f"频谱数据缺少字段: {', '.join(sorted(missing_keys))}")

        frequency = np.asarray(spectrum_data["F"], dtype=float)
        impedance = np.asarray(spectrum_data["Z"], dtype=float)
        phase = np.asarray(spectrum_data["Ph"], dtype=float)
        if frequency.ndim != 1:
            raise ValueError("F 必须是一维数组")
        if impedance.ndim != 2 or impedance.shape[1] != 3:
            raise ValueError("Z 必须是包含 Z、Zn、Zp 三列的二维数组")
        if phase.ndim != 2 or phase.shape[1] != 3:
            raise ValueError("Ph 必须是包含 Ph、Phn、Php 三列的二维数组")
        if not (len(frequency) == len(impedance) == len(phase)):
            raise ValueError("F、Z、Ph 的频率点数量必须一致")
        return frequency, impedance, phase

    def save_frequency_spectrum_result(
        self,
        spectrum_data: Annotated[
            Mapping[str, Any], Field(description="包含 F、Z 和 Ph 字段的频谱数据")
        ],
        save_path: Annotated[
            str | os.PathLike[str] | None,
            Field(description="结果根目录；未指定时使用当前目录下的 results"),
        ] = None,
        project_key: Annotated[
            str, Field(description="用于创建结果子目录的模型标识")
        ] = "qingyuanGRID",
        timestamp: Annotated[
            str | None,
            Field(description="保存文件使用的统一时间戳；未指定时自动生成"),
        ] = None,
    ) -> dict[str, str]:
        """将解析后的频谱数据保存为 JSON 文件。

        保存前会校验并规范化 ``F``、``Z`` 和 ``Ph`` 三组数据，然后按
        ``save_path/project_key`` 归档。传入 ``timestamp`` 时，文件名使用
        调用方提供的统一时间戳；未传入时才由本方法自动生成。

        Returns:
            包含 ``json`` 键的字典，其值为已保存 JSON 结果文件的路径。

        Raises:
            ValueError: 频谱字段缺失、数组形状不正确或频率点数量不一致时抛出。
            OSError: 结果目录或 JSON 文件无法创建、写入时抛出。
        """
        # 先统一输入数据的类型和形状，避免生成结构不完整的结果文件。
        frequency, impedance, phase = self._normalize_frequency_spectrum_data(
            spectrum_data
        )

        # 每次保存均按项目归档，并使用时间戳避免覆盖此前的扫频结果。
        base_path = (
            Path("results")
            if save_path is None or save_path == ""
            else Path(save_path)
        )
        output_path = base_path / project_key
        output_path.mkdir(parents=True, exist_ok=True)

        timestamp_text = timestamp or time.strftime("%Y_%m_%d_%H_%M_%S")
        json_path = self._timestamped_file_path(
            output_path / "HarmFre.json", timestamp_text
        )

        # JSON 保留解析后的原始频率、阻抗幅值和相位，便于后续重新绘图。
        serializable_data = {
            "F": frequency.tolist(),
            "Z": impedance.tolist(),
            "Ph": phase.tolist(),
        }
        with json_path.open("w", encoding="utf-8") as file:
            json.dump(serializable_data, file, indent=4, ensure_ascii=False)

        return {"json": str(json_path)}

    def read_frequency_spectrum_plot_nyquist_file(
        self,
        source: Annotated[
            Mapping[str, Any] | str | os.PathLike[str],
            Field(description="频谱数据字典或保存该数据的 JSON 文件路径"),
        ],
        *,
        show: Annotated[
            bool, Field(description="是否立即显示图表并输出谐振风险判断")
        ] = True,
        html_dir: Annotated[
            str | os.PathLike[str] | None,
            Field(description="分析图 HTML 输出目录；为 None 时不保存"),
        ] = None,
        timestamp: Annotated[
            str | None,
            Field(description="保存文件使用的统一时间戳；未指定时自动生成"),
        ] = None,
    ) -> dict[str, Any]:
        """读取频谱并生成阻抗、相位、阻尼系数和奈奎斯特图。

        ``source`` 可以是内存中的频谱字典，也可以是此前保存的 JSON
        文件。提供 ``html_dir`` 时，四张分析图会分别保存为带时间戳的
        Plotly HTML。对同一仿真流程，应传入与 JSON 和原始波形相同的
        ``timestamp``。

        Returns:
            包含 ``magnitude``、``phase``、``damping`` 和 ``nyquist``
            四个 Plotly 图形对象，以及 ``html_files`` 文件路径映射和
            ``resonance_risk`` 谐振风险判断结果的字典。未要求保存时，
            ``html_files`` 为空字典。

        Raises:
            TypeError: ``source`` 不是频谱数据映射或文件路径时抛出。
            ValueError: 频谱字段缺失、数组形状不正确或频率点数量不一致时抛出。
            OSError: 输入 JSON 无法读取或分析图 HTML 无法写入时抛出。
        """
        if isinstance(source, Mapping):
            spectrum_data = source
        elif isinstance(source, (str, os.PathLike)):
            with Path(source).open("r", encoding="utf-8") as file:
                spectrum_data = json.load(file)
        else:
            raise TypeError("source 必须是解析结果字典或 JSON 文件路径")

        # 统一数据结构，并排除基频附近 40～60 Hz 的区间，以突出扫频特征。
        frequency, impedance, phase = self._normalize_frequency_spectrum_data(
            spectrum_data
        )
        selected = (frequency <= 40) | (frequency >= 60)
        frequency = frequency[selected]
        impedance = impedance[selected]
        phase = phase[selected]

        # 分别绘制正序和负序阻抗的幅频曲线。
        magnitude_figure = go.Figure(
            layout=go.Layout(
                template="plotly_white",
                title="阻抗幅值频谱",
                xaxis=dict(title="频率 (Hz)", type="log"),
                yaxis=dict(title="阻抗幅值 (dB)"),
            )
        )
        for index, name in ((1, "Zn"), (2, "Zp")):
            magnitude_figure.add_trace(
                go.Scatter(
                    x=frequency, y=impedance[:, index], mode="lines", name=name
                )
            )

        # 分别绘制正序和负序阻抗的相频曲线。
        phase_figure = go.Figure(
            layout=go.Layout(
                template="plotly_white",
                title="阻抗相位频谱",
                xaxis=dict(title="频率 (Hz)", type="log"),
                yaxis=dict(title="阻抗相位 (°)"),
            )
        )
        for index, name in ((1, "Phn"), (2, "Php")):
            phase_figure.add_trace(
                go.Scatter(x=frequency, y=phase[:, index], mode="lines", name=name)
            )

        # 将 dB 和角度转换为极坐标量，计算正负序阻抗组合的阻尼系数。
        negative_magnitude = 10 ** (impedance[:, 1] / 20)
        positive_magnitude = 10 ** (impedance[:, 2] / 20)
        negative_phase = np.deg2rad(phase[:, 1])
        positive_phase = np.deg2rad(phase[:, 2])
        damping_numerator = (
            negative_magnitude * np.cos(negative_phase)
            + positive_magnitude * np.cos(positive_phase)
        )
        denominator_radicand = -(
            negative_magnitude
            * np.sin(negative_phase)
            * positive_magnitude
            * np.sin(positive_phase)
        )

        # 该指标仅在根号项为正且参与计算的数据有限时具有实数意义。
        # 其余频率点保留为 NaN，使 Plotly 将其显示为曲线断点，避免把
        # 无实数意义的复数结果误画成零值。
        damping_coefficient = np.full_like(
            denominator_radicand, np.nan, dtype=float
        )
        valid_damping = (
            np.isfinite(damping_numerator)
            & np.isfinite(denominator_radicand)
            & (denominator_radicand > 0)
        )
        damping_coefficient[valid_damping] = damping_numerator[valid_damping] / (
            2 * np.sqrt(denominator_radicand[valid_damping])
        )

        damping_figure = go.Figure(
            layout=go.Layout(
                template="plotly_white",
                title="阻尼系数",
                xaxis=dict(title="频率 (Hz)", type="log"),
                yaxis=dict(title="阻尼系数"),
            )
        )
        damping_figure.add_trace(
            go.Scatter(
                x=frequency, y=damping_coefficient, mode="lines", name="阻尼系数"
            )
        )

        # 构造半径为 0.2 的风险边界，并计算网侧/机侧阻抗比的极坐标轨迹。
        # 扫频模块的 Pos 端对应网侧，Neg 端对应机侧，因此该比值为 Zp/Zn。
        radians = np.arange(0, 2 * np.pi, 0.01)
        radius = 0.2
        boundary_angle = np.pi - np.arctan(
            radius * np.sin(radians) / (1 - radius * np.cos(radians))
        )
        boundary_radius = np.sqrt(
            (radius * np.sin(radians)) ** 2
            + (1 - radius * np.cos(radians)) ** 2
        )
        ratio_angle = np.deg2rad(phase[:, 2] - phase[:, 1])
        ratio_radius = 10 ** ((impedance[:, 2] - impedance[:, 1]) / 20)
        boundary_cartesian = np.column_stack(
            (
                boundary_radius * np.cos(boundary_angle),
                boundary_radius * np.sin(boundary_angle),
            )
        )
        ratio_cartesian = np.column_stack(
            (
                ratio_radius * np.cos(ratio_angle),
                ratio_radius * np.sin(ratio_angle),
            )
        )

        # 与历史算法一致：将两条极坐标曲线转换为笛卡尔坐标路径，再用
        # Matplotlib Path 判断阻抗比轨迹是否与风险边界相交。
        resonance_risk = MatplotlibPath(boundary_cartesian).intersects_path(
            MatplotlibPath(ratio_cartesian)
        )

        # 在极坐标中叠加风险边界与阻抗比轨迹，形成奈奎斯特诊断图。
        nyquist_figure = go.Figure(
            layout=go.Layout(
                template="plotly_white",
                title="网侧/机侧阻抗比奈奎斯特图 ($Z_{grid}/Z_{machine}$)",
                polar=dict(
                    angularaxis=dict(thetaunit="radians"),
                    radialaxis=dict(title="阻抗比幅值"),
                ),
            )
        )
        nyquist_figure.add_trace(
            go.Scatterpolar(
                theta=boundary_angle,
                r=boundary_radius,
                thetaunit="radians",
                mode="lines",
                name="风险边界",
                line=dict(color="green", dash="dash"),
                fill="toself",
                fillcolor="rgba(0, 128, 0, 0.2)",
            )
        )
        nyquist_figure.add_trace(
            go.Scatterpolar(
                theta=ratio_angle,
                r=ratio_radius,
                thetaunit="radians",
                mode="lines",
                name="$Z_{grid}/Z_{machine}$",
                line=dict(color="black", dash="dash"),
            )
        )

        html_files: dict[str, str] = {}
        if html_dir is not None:
            # 四张分析图分别保存，便于在浏览器中单独查看或归档。
            output_dir = Path(html_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            timestamp_text = timestamp or time.strftime("%Y_%m_%d_%H_%M_%S")
            figures = {
                "magnitude": magnitude_figure,
                "phase": phase_figure,
                "damping": damping_figure,
                "nyquist": nyquist_figure,
            }
            for name, figure in figures.items():
                output_path = self._timestamped_file_path(
                    output_dir / f"{name}.html",
                    timestamp_text,
                )
                figure.write_html(str(output_path), include_plotlyjs=True)
                html_files[name] = str(output_path)

        # show=False 时仅返回图形对象，适合批处理或无图形界面的运行环境。
        if show:
            magnitude_figure.show()
            phase_figure.show()
            damping_figure.show()
            nyquist_figure.show()
            print(" 是否有谐振风险: ", resonance_risk)

        return {
            "magnitude": magnitude_figure,
            "phase": phase_figure,
            "damping": damping_figure,
            "nyquist": nyquist_figure,
            "html_files": html_files,
            "resonance_risk": resonance_risk,
        }


    _MODEL_TEMPLATE = Template(
        """${model}:model(input:{ rid: "${rid}" }) {
            rid
            name
            description
            tags
            revision { parameters pins documentation }
        }"""
    )

    @classmethod
    def fetch_comp_data(cls, rids: list[str]) -> dict[str, Any]:
        """通过 GraphQL 批量获取指定 RID 对应的 CloudPSS 元件定义。

        每个 RID 会生成一个独立的查询别名；输入列表为空时不发送请求。

        Returns:
            以 GraphQL 查询别名为键、元件定义数据为值的字典；``rids``
            为空时返回空字典。

        Raises:
            RuntimeError: GraphQL 请求失败或响应不包含预期数据时，底层 SDK
                可能抛出该异常。
        """
        if not rids:
            return {}
        models = [
            cls._MODEL_TEMPLATE.safe_substitute(model=f"model{index}", rid=rid)
            for index, rid in enumerate(rids, start=1)
        ]
        data = cloudpss.utils.graphql_request(f"query {{ {' '.join(models)} }}", {})
        return data["data"]

    @classmethod
    def generate_parameter_dict(
        cls, token: str, api_url: str, project_rid: str
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """读取项目内使用的元件定义，整理参数和引脚元数据。

        方法会配置 CloudPSS 连接信息、获取指定项目，并批量查询项目内
        各类元件的定义；相同 RID 只查询一次。

        Returns:
            ``(parameter_dict, pin_dict)`` 元组。前者按元件 RID 保存元件
            名称及参数定义，后者按元件 RID 保存引脚定义。

        Raises:
            RuntimeError: 项目或元件定义无法从 CloudPSS 获取时，底层 SDK
                可能抛出该异常。
        """
        cloudpss.setToken(token)
        os.environ["CLOUDPSS_API_URL"] = api_url
        project = cloudpss.Model.fetch(project_rid)
        definitions = {
            component_json["definition"]
            for component in project.getAllComponents().values()
            if "definition" in (component_json := component.toJSON())
        }
        raw_definitions = cls.fetch_comp_data(sorted(definitions))

        parameter_dict: dict[str, Any] = {}
        pin_dict: dict[str, Any] = {}
        for raw_data in raw_definitions.values():
            rid = raw_data["rid"]
            parameter_dict[rid] = {"DiscriptName": raw_data["name"]}
            pin_dict[rid] = {}
            for parameter_group in raw_data["revision"]["parameters"]:
                for item in parameter_group["items"]:
                    parameter_dict[rid][item["key"]] = item
            for item in raw_data["revision"]["pins"]:
                pin_dict[rid][item["key"]] = item
        return parameter_dict, pin_dict
