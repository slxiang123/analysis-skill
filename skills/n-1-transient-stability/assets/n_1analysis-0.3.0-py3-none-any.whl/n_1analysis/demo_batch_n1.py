"""CloudPSS 批量 N-1 暂态稳定分析流程案例（环境变量驱动）。

复用 ``demo_n1.run_scenario`` 作为单场景函数（场景隔离由其内部
新建工具箱实例保证），批量编排交给 ``n_1analysis.batch.run_batch``。
支持三种批量模式（``N1_BATCH_MODE``）：

- ``random``：随机生成 ``N1_BATCH_COUNT`` 组故障参数依次仿真
- ``keys``：遍历 ``N1_BATCH_TRANS_KEYS`` 指定的元件列表
  （逗号或分号分隔的 key/label）
- ``all``：遍历当前算例全部交流线路与变压器

批量环境变量：
    ``N1_BATCH_MODE``（默认 random）、``N1_BATCH_COUNT``（默认 2）、
    ``N1_BATCH_TRANS_KEYS``、``N1_BATCH_SEED``、``N1_BATCH_BACKEND``
    （默认 sequential，可选 ray）、``N1_BATCH_MAX_WORKERS``（默认 2）、
    ``N1_BATCH_STOP_ON_ERROR``（默认 false）。

连接与仿真参数复用单次案例的 ``SIMSTUDIO_TOKEN``（或
``CLOUDPSS_TOKEN``）、``CLOUDPSS_MODEL``、``N1_END_TIME`` 等环境
变量；本地结果根目录由 ``N1_SAVE_PATH`` 配置。

注意：keys 模式的逐项故障覆盖（每个元件不同的故障类型/时间）是库层
``build_scenarios`` 的能力，请直接构建迭代项后交给 ``run_batch`` 执行。
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any
from dotenv import load_dotenv
load_dotenv()

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from n_1analysis.batch import build_scenarios, run_batch
    from n_1analysis.demo_n1 import (
        _read_bool_environment,
        _read_sim_kwargs,
        run_scenario,
    )
    from n_1analysis.n_1_analysis_toolbox import N1AnalysisToolbox
else:
    from .batch import build_scenarios, run_batch
    from .demo_n1 import (
        _read_bool_environment,
        _read_sim_kwargs,
        run_scenario,
    )
    from .n_1_analysis_toolbox import N1AnalysisToolbox


def _read_int_environment(name: str, default: int) -> int:
    value = os.getenv(name)
    return int(value) if value is not None else default


def main() -> dict[str, Any]:
    """从环境变量读取配置并运行一次批量 N-1 分析。

    Returns:
        批量汇总字典：``batch_id``、``scenarios``（每场景记录）、
        ``summary``（成功/失败/稳定通过计数）和 ``artifacts``
        （batch_result.json、batch_summary.csv、scenarios.json 路径）。
    """
    project_root = Path(__file__).resolve().parents[2]
    os.chdir(project_root)

    cloudpss_token = os.getenv("SIMSTUDIO_TOKEN") or os.getenv(
        "CLOUDPSS_TOKEN", ""
    )
    if not cloudpss_token:
        raise RuntimeError("缺少必填环境变量: SIMSTUDIO_TOKEN 或 CLOUDPSS_TOKEN")
    cloudpss_model = os.getenv("CLOUDPSS_MODEL", "")
    if not cloudpss_model:
        raise RuntimeError("缺少必填环境变量: CLOUDPSS_MODEL")
    model_parts = cloudpss_model.strip("/").split("/")
    if len(model_parts) != 3 or model_parts[0] != "model":
        raise ValueError("CLOUDPSS_MODEL 必须使用 model/用户名/模型标识 格式")

    mode = os.getenv("N1_BATCH_MODE", "random")
    if mode not in ("random", "keys", "all"):
        raise ValueError("N1_BATCH_MODE 只支持 random、keys 或 all")
    count = _read_int_environment("N1_BATCH_COUNT", 2)
    backend = os.getenv("N1_BATCH_BACKEND", "sequential")
    if backend not in ("sequential", "ray"):
        raise ValueError("N1_BATCH_BACKEND 只支持 sequential 或 ray")
    trans_keys_env = os.getenv("N1_BATCH_TRANS_KEYS", "")
    trans_keys = [
        item.strip()
        for item in trans_keys_env.replace(";", ",").split(",")
        if item.strip()
    ] or None
    seed_env = os.getenv("N1_BATCH_SEED")
    seed = int(seed_env) if seed_env is not None else None

    # 只读探查：delete_edges=False，仅构建元件索引与 label 解析，
    # 探查实例不复用于场景执行。
    print(f"[batch] 初始化只读探查实例（模型 {cloudpss_model}）...", flush=True)
    probe = N1AnalysisToolbox()
    probe.set_config(
        token=cloudpss_token,
        api_url=os.getenv("CLOUDPSS_API_URL", "https://cloudpss.net/"),
        username=model_parts[1],
        model=model_parts[2],
        delete_edges=False,
    )
    probe.set_initial_conditions()
    scenarios = build_scenarios(
        mode,
        toolbox=probe,
        count=count,
        trans_keys=trans_keys,
        seed=seed,
    )
    transmission = probe.get_transmission_keys()
    print(
        f"[batch] 模型共 {len(transmission['acline_keys'])} 条交流线路、"
        f"{len(transmission['trans_keys'])} 台变压器",
        flush=True,
    )
    print(
        f"[batch] 批量模式 {mode}，场景清单（{len(scenarios)} 个）:",
        [spec.label for spec in scenarios],
        flush=True,
    )
    del probe

    batch_result = run_batch(
        cloudpss_model,
        scenarios,
        scenario_runner=run_scenario,
        token=cloudpss_token,
        runner_kwargs=_read_sim_kwargs(),
        backend=backend,
        max_workers=_read_int_environment("N1_BATCH_MAX_WORKERS", 2),
        stop_on_error=_read_bool_environment("N1_BATCH_STOP_ON_ERROR", False),
        save_path=os.getenv("N1_SAVE_PATH") or None,
        seed=seed,
    )
    print("批量汇总:", batch_result["summary"])
    print("批次文件:", batch_result["artifacts"])
    print("=== N-1 批量分析流程完成 ===")
    return batch_result


if __name__ == "__main__":
    main()
