"""CloudPSS N-1 分析所需的最小工具集。

本类只保留 ``demo_N-1.py`` 实际使用的模型编辑、潮流采样、故障设置、
计算方案配置和暂态稳定性检查能力，用来替代对历史大型模块的依赖。
"""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import random
import re
import time
import uuid
from typing import Annotated, Any, Callable, Dict, Optional, TypeVar
from pydantic import Field

import cloudpss
import matplotlib.pyplot as plt
import numpy as np
import plotly.graph_objects as go
from cloudpss.model.implements.component import Component
from cloudpss.model import Model

_EnvValue = TypeVar("_EnvValue")
_ENVIRONMENT_NAME_PATTERN = re.compile(r"^[A-Z][A-Z0-9_]*$")


def _read_environment_variable(
    name: str,
    default: _EnvValue,
    converter: Callable[[str], _EnvValue] | None = None,
) -> _EnvValue:
    """安全读取并转换环境变量，未设置或空白时返回默认值。"""
    if not isinstance(name, str) or not _ENVIRONMENT_NAME_PATTERN.fullmatch(name):
        raise ValueError(f"非法的环境变量名称: {name!r}")

    raw_value = os.environ.get(name)
    if raw_value is None or not raw_value.strip():
        return default
    if "\x00" in raw_value:
        raise ValueError(f"环境变量 {name} 包含非法的 NUL 字符")

    normalized_value = raw_value.strip()
    if converter is None:
        return normalized_value  # type: ignore[return-value]
    try:
        return converter(normalized_value)
    except (TypeError, ValueError) as error:
        expected_type = getattr(converter, "__name__", str(converter))
        raise ValueError(
            f"环境变量 {name} 无法转换为 {expected_type}: {normalized_value!r}"
        ) from error


def _generate_result_path(
    project_key: str,
    base_path: str,
    file_prefix: str,
    file_extension: str | None = None,
    timestamp: str | None = None,
) -> str:
    """按项目、业务类型和统一时间戳生成本地结果文件路径。"""
    suffix = f".{file_extension}" if file_extension else ""
    timestamp_text = timestamp or time.strftime("%Y_%m_%d_%H_%M_%S")
    filename = f"{file_prefix}_{timestamp_text}{suffix}"
    return f"{project_key}/{base_path}/{filename}"


def _json_safe(value: Any) -> Any:
    """将分析摘要转换为可写入 JSON 的基础类型。"""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return str(value)


def _create_or_append_hdf5_dataset(
    group: Any,
    dataset_name: str,
    data: np.ndarray,
) -> None:
    """在 HDF5 组中创建数据集，批量模式下追加到首维。"""
    array = np.asarray(data)
    dataset_dtype = None
    if array.dtype.kind in {"O", "U"}:
        try:
            array = array.astype(float)
        except (TypeError, ValueError):
            import h5py

            dataset_dtype = h5py.string_dtype(encoding="utf-8")
            array = array.astype(str).astype(object)

    if dataset_name in group:
        dataset = group[dataset_name]
        if dataset.shape[1:] != array.shape[1:]:
            raise ValueError(
                f"数据集 {dataset_name} 的已有形状 {dataset.shape[1:]} "
                f"与待追加形状 {array.shape[1:]} 不一致"
            )
        old_size = dataset.shape[0]
        dataset.resize((old_size + array.shape[0],) + dataset.shape[1:])
        dataset[old_size:] = array
        return

    create_options: dict[str, Any] = {
        "data": array,
        "maxshape": (None,) + array.shape[1:],
        "chunks": True,
    }
    if dataset_dtype is not None:
        create_options["dtype"] = dataset_dtype
    group.create_dataset(dataset_name, **create_options)


SIMSTUDIO_TOKEN = _read_environment_variable("SIMSTUDIO_TOKEN", "")
CLOUDPSS_API_URL = _read_environment_variable(
    "CLOUDPSS_API_URL", "https://cloudpss.net/"
)
DEFAULT_POSITION_VALUE = _read_environment_variable(
    "CET_DEFAULT_POSITION_VALUE", 20, int
)
OUTPUT_CANVAS_MAX_X = _read_environment_variable(
    "PSAT_OUTPUT_CANVAS_MAX_X", 500, int
)
FAULT_PERMANENT_END_TIME = _read_environment_variable(
    "PSAT_FAULT_PERMANENT_END_TIME", 99999, int
)
MAX_POWER_FLOW_RETRIES = _read_environment_variable(
    "PSA_MAX_POWER_FLOW_RETRIES", 100, int
)

if DEFAULT_POSITION_VALUE < 0:
    raise ValueError("环境变量 CET_DEFAULT_POSITION_VALUE 不能小于 0")
if OUTPUT_CANVAS_MAX_X <= 0:
    raise ValueError("环境变量 PSAT_OUTPUT_CANVAS_MAX_X 必须大于 0")


class N1AnalysisToolbox:
    """当前 N-1 流程使用的 CloudPSS 分析工具。

    非下划线开头的方法为公开 API，供编写类似 ``demo_N-1.py`` 的流程
    直接调用；下划线开头的方法为内部实现，不做兼容性保证。参数说明
    见各参数的 ``Field`` 元信息，返回值与异常见方法 docstring。
    """

    def __init__(self) -> None:
        """初始化 CloudPSS N-1 分析工具状态。"""
        self.config = {
            "token": SIMSTUDIO_TOKEN,
            "api_url": CLOUDPSS_API_URL,
            "model": "test",
            "username": "admin",
            "plot_tool": "plotly",
            "delete_edges": True,
        }
        self.project: Model = None
        self.runner: Any = None
        self.topo: dict[str, Any] | None = None
        self.pos: dict[str, dict[str, float]] = {}
        self.channel_pin_dict: dict[str, str] = {}
        # label -> component key(s)。CloudPSS 中 label 不保证唯一，
        # 因此 value 一律保存为列表。
        self.comp_label_dict: dict[str, list[str]] = {}
        self.current_canvas: str | None = None
        self.bus_keys: list[str] = []
        self.gen_keys: list[str] = []
        self.load_keys: list[str] = []
        self.acline_keys: list[str] = []
        self.trans_keys: list[str] = []
        self.initial_pf_setting: list[list[Any]] = []
        self.pf_result: dict[str, Any] | None = None
        self.batch_id: str | None = None
        self.is_batch_mode = False
        self.last_plot_html_path: str | None = None
        self.run_id: str | None = None
        self.run_dir: Path | None = None
        self.stability_result: dict[str, Any] | None = None
        self.analysis_context: dict[str, Any] = {}

        self.c_fid = "canvas_AutoSA_Fault"
        self.c_oid = "canvas_AutoSA_ExtraOutput"

        self._init_job_templates()

        if self.config["token"]:
            cloudpss.setToken(self.config["token"])
        if self.config["api_url"]:
            os.environ["CLOUDPSS_API_URL"] = self.config["api_url"]

    def _init_job_templates(self) -> None:
        """初始化新版 CloudPSS 计算方案与参数方案模板。"""
        self.emtp_job_init = {
            "args": {
                "begin_time": 0,
                "debug": 0,
                "end_time": 10,
                "initial_type": 0,
                "load_snapshot": 0,
                "load_snapshot_name": "",
                "max_initial_time": 1,
                "mergeBusNode": 0,
                "n_cpu": 16,
                "output_channels": [],
                "ramping_time": 0,
                "save_snapshot": 0,
                "save_snapshot_name": "snapshot",
                "save_snapshot_time": 1,
                "solver": 0,
                "solver_option": 7,
                "step_time": 0.0001,
                "task_cmd": "",
                "task_queue": "taskManager",
            },
            "name": "CA电磁暂态仿真方案",
            "rid": "job-definition/cloudpss/emtp",
        }
        self.pf_job_init = {
            "args": {
                "@debug": "",
                "@priority": 0,
                "@queue": 1,
                "@tres": "cpu=1",
                "CheckInput": 1,
                "MaxIteration": 30,
                "ShowRunLog": 2,
                "SkipPF": 0,
                "UseBusAngleAsInit": 1,
                "UseBusVoltageAsInit": 1,
                "UseReactivePowerLimit": 1,
                "UseVoltageLimit": 1,
            },
            "name": "CA潮流计算方案",
            "rid": "function/CloudPSS/power-flow",
        }
        self.emtps_job_init = {
            "args": {
                "@debug": "",
                "@priority": 0,
                "@queue": 1,
                "@tres": "cpu=1",
                "begin_time": 0,
                "comm": [],
                "comm_freq": 1,
                "comm_protocol": 0,
                "comm_type": 0,
                "ctrlparallel_option": 0,
                "debug": 0,
                "dev_id": 1,
                "dev_num": 1,
                "end_time": 15,
                "event_option": 0,
                "init_cfg": 0,
                "initial_type": 0,
                "kernel_option": 1,
                "load_snapshot": "0",
                "load_snapshot_name": "",
                "max_initial_time": 1,
                "mergeBusNode": 0,
                "multi_dev_partition": [],
                "n_cpu": 1,
                "n_ele_cpu": 1,
                "only_partition": 0,
                "output_channels": [],
                "partition_info": [
                    {"0": 0, "1": "", "2": "", "ɵid": 25021700}
                ],
                "partition_msg_output": 1,
                "partition_option": 0,
                "ramping_time": 0,
                "realtime_timeout": 10,
                "save_snapshot": 0,
                "save_snapshot_name": "snapshot",
                "save_snapshot_time": 1,
                "sim_option": 0,
                "snapshot_cfg": 0,
                "solver": 0,
                "solver_option": 0,
                "step_time": 0.00001,
                "task_cmd": "",
            },
            "name": "CA电磁暂态仿真方案_新",
            "rid": "function/CloudPSS/emtps",
        }
        self.project_config_init = {"args": {}, "name": "CA参数方案", "pins": {}}

    def set_config(
        self,
        token: Annotated[str, Field(description="从 cloudpss 平台中申请的 token。")] = None,
        api_url: Annotated[str, Field(description="API 域名地址。")] = None,
        username: Annotated[str, Field(description="用户名。")] = None,
        model: Annotated[str, Field(description="算例名称（不带/model/username）。")] = None,
        delete_edges: Annotated[bool, Field(description="是否将所有的连接线都删除，统一使用引脚管理连接关系")] = None,
    ) -> None:
        """更新 CloudPSS 连接配置和模型编辑选项。

        只更新显式提供的字段；设置 ``token``/``api_url`` 会同步到
        CloudPSS SDK 和环境变量 ``CLOUDPSS_API_URL``。

        Returns:
            None。配置原地写入 ``config`` 属性。

        Raises:
            ValueError: 字符串参数为空或非字符串。
            TypeError: ``delete_edges`` 非布尔值。
        """
        string_values = {
            "token": token,
            "api_url": api_url,
            "username": username,
            "model": model,
        }
        for name, value in string_values.items():
            if value is not None and (not isinstance(value, str) or not value):
                raise ValueError(f"{name} 参数必须是非空字符串或 None")


        if delete_edges is not None and not isinstance(delete_edges, bool):
            raise TypeError("delete_edges 参数必须是布尔类型或 None")

        updates = {
            "token": token,
            "api_url": api_url,
            "username": username,
            "model": model,
            "delete_edges": delete_edges,
        }
        self.config.update({key: value for key, value in updates.items() if value is not None})

        if token is not None:
            cloudpss.setToken(token)
        if api_url is not None:
            os.environ["CLOUDPSS_API_URL"] = api_url

    def set_initial_conditions(self) -> None:
        """校验配置，拉取模型并初始化元件索引、通道索引与潮流初值。

        ``delete_edges`` 为真时先把图形边转换为命名引脚连接。

        Returns:
            None。状态写入 ``project``、各类 ``*_keys``、
            ``channel_pin_dict``、``initial_pf_setting`` 等属性。

        Raises:
            RuntimeError: 配置缺失，或模型/拓扑初始化失败。
        """
        missing = [
            name
            for name in ("token", "api_url", "username", "model")
            if not self.config.get(name)
        ]
        if missing:
            raise RuntimeError(f"CloudPSS 运行配置缺失: {', '.join(missing)}")

        cloudpss.setToken(self.config["token"])
        os.environ["CLOUDPSS_API_URL"] = self.config["api_url"]
        model_rid = f'model/{self.config["username"]}/{self.config["model"]}'
        print("正在获取算例...")
        self.project = cloudpss.Model.fetch(model_rid)

        # 模型就绪后立刻建立 label 索引，调用方随后既可以传 CloudPSS
        # key，也可以传可见 label。
        self._set_comp_label_dict()



        if self.config["delete_edges"]:
            self._refresh_topology()
            self._delete_edges()

        self._set_channel_pin_dict()

        self.bus_keys = self._get_bus_all_keys()
        self.gen_keys = self._get_generator_all_keys()
        self.load_keys = self._get_load_all_keys()
        self.acline_keys = self._get_acline_all_keys()
        self.trans_keys = self._get_transformer_all_keys()
        self.initial_pf_setting = self._get_power_flow_settings()

        canvases = self.project.revision.implements.diagram.canvas
        if canvases:
            self.current_canvas = canvases[0]["key"]
            self._init_canvas_position(self.current_canvas)
        else:
            self.current_canvas = None

    def _set_comp_label_dict(self) -> dict[str, list[str]]:
        """构建 ``label -> [component_key, ...]`` 的元件索引。

        CloudPSS 允许不同元件使用相同的显示 label，因此 value 保存为
        key 列表而不是直接覆盖。索引中的 key 按模型返回顺序保存且不
        重复；没有有效 label 的元件不加入索引。

        Returns:
            当前模型的元件 label 索引。返回值与
            :attr:`comp_label_dict` 使用同一份字典。

        Raises:
            RuntimeError: 尚未获取模型，或模型元件列表不可用时。
        """
        if self.project is None:
            raise RuntimeError("项目尚未初始化，请先调用 set_initial_conditions()")

        try:
            components = self.project.getAllComponents()
        except (AttributeError, TypeError) as error:
            raise RuntimeError("无法获取项目元件列表") from error
        if components is None:
            raise RuntimeError("无法获取项目元件列表")

        label_dict: dict[str, list[str]] = {}
        for component_key, component in components.items():
            if not isinstance(component_key, str) or not component_key:
                continue

            # 只索引图形元件；diagram-edge 是连接线，不是用户可选择的
            # 元件。
            shape = getattr(component, "shape", None)
            if not isinstance(shape, str) or "diagram-component" not in shape:
                continue
            label = getattr(component, "label", None)
            if not isinstance(label, str) or not label:
                continue

            keys = label_dict.setdefault(label, [])
            if component_key not in keys:
                keys.append(component_key)

        self.comp_label_dict = label_dict
        return self.comp_label_dict

    def _cache_component_label(self, component_key: str, label: str | None) -> None:
        """将一个组件的 label 增量写入索引，保留重复 label 的所有 key。"""
        if not isinstance(component_key, str) or not component_key:
            return
        if not isinstance(label, str) or not label:
            return
        keys = self.comp_label_dict.setdefault(label, [])
        if component_key not in keys:
            keys.append(component_key)

    def _remove_cached_component_label(
        self, component_key: str | None = None, label: str | None = None
    ) -> None:
        """从索引移除组件 key；同一 label 的其它 key 保持不变。"""
        if label is not None:
            keys = self.comp_label_dict.get(label, [])
            if component_key in keys:
                keys.remove(component_key)
            if not keys:
                self.comp_label_dict.pop(label, None)
            return

        if component_key:
            for cached_label, keys in list(self.comp_label_dict.items()):
                if component_key in keys:
                    keys.remove(component_key)
                if not keys:
                    self.comp_label_dict.pop(cached_label, None)

    def resolve_component_key(self, component_key: str) -> str:
        """将元件 key 或显示 label 解析为可用于模型操作的唯一 key。

        传入真实 key 时直接返回该 key；传入 label 时从
        :attr:`comp_label_dict` 查找。若一个 label 对应多个元件，无法
        安全地替用户选择，方法会抛出包含全部候选 key 的异常，请调用方
        让用户选择后再次传入候选 key。

        Returns:
            str：已确认存在且唯一的元件 key。

        Raises:
            ValueError: ``component_key`` 不是非空字符串，或 label 对应
                多个元件（异常消息列出全部候选 key）。
            KeyError: 既不是有效 key，也不是已知 label。
            RuntimeError: 项目尚未初始化。
        """
        if not isinstance(component_key, str) or not component_key:
            raise ValueError("component_key 必须是非空字符串")
        if self.project is None:
            raise RuntimeError("项目尚未初始化，请先调用 set_initial_conditions()")

        # key 是唯一标识，优先确认 key；这样即使某个 label 恰好与 key
        # 同名，也不会把一个明确的 key 误判成重复 label。
        try:
            component = self.project.getComponentByKey(component_key)
        except Exception:
            component = None
        if component is not None:
            return component_key

        candidates = self.comp_label_dict.get(component_key)
        if candidates is None:
            # 支持模型在初始化后被外部修改的场景，并让直接构造测试
            # 实例后首次调用时也能建立索引。
            candidates = self._set_comp_label_dict().get(component_key)

        if candidates:
            if len(candidates) == 1:
                return candidates[0]
            candidate_text = ", ".join(candidates)
            raise ValueError(
                f"元件 label '{component_key}' 对应多个 key: "
                f"[{candidate_text}]；请用户选择一个最终 key 后重新传入。"
            )

        raise KeyError(f"元件 key 或 label '{component_key}' 无效")

    def _refresh_topology(self) -> dict[str, Any]:
        """根据当前模型 revision 和参数方案重新获取 EMTP 拓扑。"""
        if self.project is None:
            raise RuntimeError("项目尚未初始化，请先调用 set_initial_conditions()")
        if not getattr(self.project, "revision", None):
            raise RuntimeError("当前项目缺少 revision")

        try:
            current_config = self.project.context["currentConfig"]
            config = self.project.configs[current_config]
        except (AttributeError, KeyError, IndexError, TypeError) as error:
            raise RuntimeError("无法获取当前参数方案") from error

        revision = cloudpss.ModelRevision.create(self.project.revision)
        if not isinstance(revision, dict) or not revision.get("hash"):
            raise RuntimeError("创建模型 revision 失败：返回结果中缺少 hash")

        topology = cloudpss.ModelTopology.fetch(
            revision["hash"],
            "emtp",
            config,
            maximumDepth=0,
        )
        self.topo = topology.toJSON()
        return self.topo

    def _get_edge_topology_pin_number(
        self, cid: str, _visited: set[str] | None = None
    ) -> str:
        """递归查找图形边连接的拓扑引脚编号。"""
        if not isinstance(cid, str) or not cid:
            raise ValueError("cid 参数必须是非空字符串")
        if self.project is None:
            raise RuntimeError("项目尚未初始化")
        if not isinstance(self.topo, dict) or "components" not in self.topo:
            raise RuntimeError("拓扑尚未初始化，请先调用 _refresh_topology()")

        visited = set() if _visited is None else _visited
        if cid in visited:
            raise RuntimeError(f"检测到边的循环引用: {cid}")
        visited.add(cid)

        edge = self.project.getComponentByKey(cid)
        if edge is None or getattr(edge, "shape", None) != "diagram-edge":
            raise ValueError(f"元件 '{cid}' 不是有效的 diagram-edge")

        for endpoint in (edge.source, edge.target):
            if not isinstance(endpoint, dict) or "cell" not in endpoint:
                continue

            component_id = endpoint["cell"]
            if "port" not in endpoint:
                return self._get_edge_topology_pin_number(component_id, visited)

            topology_component = self.topo["components"].get(f"/{component_id}")
            if topology_component is None:
                return "0"
            return str(topology_component.get("pins", {}).get(endpoint["port"], "0"))

        return "0"

    def _delete_edges(self) -> int:
        """将图形边转换为命名引脚连接并删除所有 ``diagram-edge``。"""
        if self.project is None:
            raise RuntimeError("项目尚未初始化")
        if not isinstance(self.topo, dict):
            raise RuntimeError("拓扑尚未初始化，请先调用 _refresh_topology()")

        topology_components = self.topo.get("components")
        mappings = self.topo.get("mappings", {})
        if not isinstance(topology_components, dict):
            raise RuntimeError("拓扑数据缺少 components")
        input_mappings = mappings.get("in", {})
        output_mappings = mappings.get("out", {})

        self.topology_pin_name_dict: dict[int, list[Any]] = {}
        for topology_id, topology_component in topology_components.items():
            component_id = topology_id.removeprefix("/")
            component = self.project.getComponentByKey(component_id)

            for port, topology_pin in topology_component.get("pins", {}).items():
                if topology_pin in (None, ""):
                    continue
                pin_number = int(topology_pin)
                pin_names = self.topology_pin_name_dict.setdefault(pin_number, [])
                pin_name = component.pins.get(port, "")
                if pin_name not in (None, "") and pin_name not in pin_names:
                    pin_names.append(pin_name)

            for argument, mapping_key in topology_component.get("args", {}).items():
                mapping_key_text = str(mapping_key)
                if mapping_key_text in input_mappings:
                    mapped_pin = input_mappings[mapping_key_text]
                elif mapping_key_text in output_mappings:
                    mapped_pin = output_mappings[mapping_key_text]
                else:
                    continue

                pin_number = int(mapped_pin)
                pin_names = self.topology_pin_name_dict.setdefault(pin_number, [])
                argument_value = component.args.get(argument, "")
                if isinstance(argument_value, dict):
                    argument_value = argument_value.get("source", "")
                if argument_value not in (None, "") and argument_value not in pin_names:
                    pin_names.append(argument_value)

        automatic_prefix = f'AutoAddPin{time.strftime("%Y%m%d%H%M%S")}_'
        automatic_index = 0
        for pin_names in self.topology_pin_name_dict.values():
            if not pin_names:
                pin_names.append(f"{automatic_prefix}{automatic_index}")
                automatic_index += 1

        edges_by_pin: dict[int, list[str]] = {}
        for component_id, component in list(self.project.getAllComponents().items()):
            if component.shape != "diagram-edge":
                continue
            topology_pin = int(self._get_edge_topology_pin_number(component_id))
            edges_by_pin.setdefault(topology_pin, []).append(component_id)

        deleted_count = 0
        cells = self.project.revision.implements.diagram.cells
        for topology_pin, edge_ids in edges_by_pin.items():
            pin_names = self.topology_pin_name_dict.get(topology_pin)
            if not pin_names:
                pin_names = [f"{automatic_prefix}{automatic_index}"]
                self.topology_pin_name_dict[topology_pin] = pin_names
                automatic_index += 1
            pin_name = pin_names[0]

            for edge_id in edge_ids:
                edge = self.project.getComponentByKey(edge_id)
                for endpoint in (edge.source, edge.target):
                    if not isinstance(endpoint, dict):
                        continue
                    if "cell" not in endpoint or "port" not in endpoint:
                        continue
                    endpoint_component = self.project.getComponentByKey(endpoint["cell"])
                    if endpoint_component.pins.get(endpoint["port"], "") == "":
                        endpoint_component.pins[endpoint["port"]] = pin_name
                cells.pop(edge_id, None)
                deleted_count += 1

        return deleted_count

    def _set_channel_pin_dict(self) -> None:
        """建立输出引脚到通道元件 key 的索引。"""
        self.channel_pin_dict = {}
        channels = self.project.getComponentsByRid("model/CloudPSS/_newChannel")
        for key in channels:
            component = self.project.getComponentByKey(key)
            self.channel_pin_dict[str(component.pins["0"])] = key

    def _init_canvas_position(self, canvas: str) -> None:
        """初始化指定画布的元件布局坐标。"""
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")

        self.pos[canvas] = {
            "dx": DEFAULT_POSITION_VALUE,
            "dy": DEFAULT_POSITION_VALUE,
            "x0": DEFAULT_POSITION_VALUE,
            "y0": DEFAULT_POSITION_VALUE,
            "x": DEFAULT_POSITION_VALUE,
            "y": DEFAULT_POSITION_VALUE,
            "maxdy": 0,
        }

    def create_canvas(
        self,
        canvas: Annotated[str, Field(description="图纸的key")],
        name: Annotated[str, Field(description="图纸的名称")],
    ) -> None:
        """创建画布并初始化其元件布局坐标。

        Returns:
            None。画布追加到模型 revision，布局状态写入 ``pos``。

        Raises:
            ValueError: ``canvas`` 或 ``name`` 为空或非字符串。
        """
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")
        if not isinstance(name, str) or not name:
            raise ValueError("name 参数必须是非空字符串")

        self.project.revision.implements.diagram.canvas.append({"key": canvas, "name": name})
        self._init_canvas_position(canvas)

    def create_sa_canvas(self) -> None:
        """确保 N-1 流程使用的故障及输出图纸存在，并初始化布局。

        已有图纸仅重置布局游标；同时确保故障画布存在接地点元件。
        可重复调用。

        Returns:
            None。图纸与接地点写入模型，布局状态写入 ``pos``。

        Raises:
            RuntimeError: 尚未调用 :meth:`set_initial_conditions`。
        """
        existing = {
            canvas["key"] for canvas in self.project.revision.implements.diagram.canvas
        }
        for canvas, name in (
            (self.c_fid, "N-1 故障相关设置"),
            (self.c_oid, "N-1 分析所需输出通道"),
        ):
            if canvas not in existing:
                self.create_canvas(canvas, name)
            else:
                self._init_canvas_position(canvas)

        ground_components = self.project.getComponentsByRid("model/CloudPSS/GND")
        if not any(
            getattr(component, "canvas", None) == self.c_fid
            for component in ground_components.values()
        ):
            self.add_comp_in_canvas(
                "model/CloudPSS/GND",
                canvas=self.c_fid,
                args={"Name": "接地点(用于稳定分析)"},
                pins={"0": "GND"},
                label="接地点(用于稳定分析)",
            )
        self.new_line_position(self.c_fid)

    def _add_x_position(
        self, canvas: str, max_x: float | None = None
    ) -> None:
        """根据元件尺寸推进画布横坐标，并在超过限制时换行。"""


        self.pos[canvas]["x"] += 200
        self.pos[canvas]["maxdy"] = max(
            self.pos[canvas]["maxdy"], 300
        )
        if max_x is not None and self.pos[canvas]["x"] > max_x:
            self.new_line_position(canvas)

    def new_line_position(
        self,
        canvas: Annotated[str, Field(description="当前图纸的key")]
    ) -> None:
        """将指定画布的布局游标移动到新一行起点。

        Returns:
            None。``x`` 重置为 ``x0``，``y`` 下移一行，``maxdy`` 清零。

        Raises:
            ValueError: ``canvas`` 为空或布局状态未初始化。
        """
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")
        if canvas not in self.pos:
            raise ValueError(f"canvas '{canvas}' 未在 pos 字典中初始化")

        self.pos[canvas]["x"] = self.pos[canvas]["x0"]
        self.pos[canvas]["y"] += self.pos[canvas]["dy"] + self.pos[canvas]["maxdy"]
        self.pos[canvas]["maxdy"] = 0

    def add_comp_in_canvas(
        self,
        definition: Annotated[str, Field(description="元件的RID")],
        canvas: Annotated[str, Field(description="元件所在的画布")],
        args: Annotated[dict, Field(description="元件的参数")] = None,
        pins: Annotated[dict, Field(description="元件的引脚")] = None,
        label: Annotated[str, Field(description="元件的标签")] = None,
        d_x: Annotated[int, Field(description="元件之间的x轴间距")] = 10,
        max_x: Annotated[float, Field(description="换行参数，图纸中一行元件的最大宽度")] = None
    ) -> tuple[str, str]:
        """在指定画布当前布局位置新增元件，并推进布局游标。

        Returns:
            ``(component_id, label)``：平台生成的元件 ID 和本次使用的
            标签（未提供时第二项为 ``None``）。

        Raises:
            KeyError: ``canvas`` 布局状态未初始化。
            RuntimeError: 模型未初始化。
            ValueError: 元件定义或参数被 CloudPSS 拒绝。
        """

        position = {name: self.pos[canvas][name] for name in ("x", "y")}
        component_args = args.copy() if args is not None else {}

        comp_rs = self.project.addComponent(
            definition, label, component_args, pins, canvas, position
        )
        component_id = comp_rs.id
        self._cache_component_label(component_id, label)
        self._add_x_position(canvas, max_x)
        self.pos[canvas]["x"] += d_x
        return component_id, label

    def add_channel(
        self,
        pin_name: Annotated[str, Field(description="要添加输出通道的引脚名")],
        dim: Annotated[int, Field(description="输出通道的维度")],
        channel_name: Annotated[str, Field(description="输出通道的名称")] = None,
    ) -> tuple[str, str]:
        """为指定引脚新增或复用一个输出通道元件。

        同一引脚重复调用会复用已有通道；提供 ``channel_name`` 时同步
        更新其名称。需先调用 :meth:`create_sa_canvas` 初始化输出画布。

        Returns:
            ``(component_id, label)``：输出通道元件 ID 及标签。

        Raises:
            KeyError: 输出画布布局未初始化。
            RuntimeError: 模型或通道索引未初始化。
        """

        if pin_name not in self.channel_pin_dict:
            component_label = pin_name if channel_name is None else channel_name
            component_id, label = self.add_comp_in_canvas(
                "model/CloudPSS/_newChannel",
                canvas=self.c_oid,
                args={"Name": component_label, "Dim": dim},
                pins={"0": pin_name},
                label=component_label,
                max_x=OUTPUT_CANVAS_MAX_X,
            )
            self.channel_pin_dict[pin_name] = component_id
            return component_id, label

        component = self.project.getComponentByKey(self.channel_pin_dict[pin_name])
        if channel_name is not None:
            old_label = getattr(component, "label", None)
            component.args["Name"] = channel_name
            component.label = channel_name
            self._remove_cached_component_label(component.id, old_label)
            self._cache_component_label(component.id, channel_name)
        return component.id, component.label

    def create_job(
        self,
        stype: Annotated[str, Field(description="计算方案的类型，'emtps'表示电磁暂态仿真，'power-flow'表示潮流计算")] = 'emtps',
        name: Annotated[str, Field(description="计算方案的名称")] = None,
        args: Annotated[Dict, Field(description="计算方案的配置。仅支持使用原始参数 key 进行增量更新")] = None,
    ) -> None:
        """按内置模板新增计算方案。

        ``args`` 按原始参数 key 增量覆盖模板；不做同名判重，重复调用
        会添加多个同名方案。

        Returns:
            None。方案追加到模型计算方案列表。

        Raises:
            ValueError: ``stype`` 不支持或 ``name`` 为空。
            TypeError: ``args`` 非字典。
            RuntimeError: 模型未初始化。
        """
        if not isinstance(stype, str) or not stype:
            raise ValueError("stype 参数必须是非空字符串")
        if name is not None and (not isinstance(name, str) or not name):
            raise ValueError("name 参数必须是非空字符串或 None")
        if args is not None and not isinstance(args, dict):
            raise TypeError("args 参数必须是字典或 None")

        templates = {
            "emtp": self.emtp_job_init,
            "emtps": self.emtps_job_init,
            "power-flow": self.pf_job_init,
            "powerFlow": self.pf_job_init,
        }
        if stype not in templates:
            raise ValueError(f"不支持的计算方案类型: {stype}")
        job = copy.deepcopy(templates[stype])
        if name is not None:
            job["name"] = name
        if args:
            job["args"].update(args)
        self.project.addJob(job)

    def create_config(
        self,
        name: Annotated[str, Field(description="参数方案名称")] = None,
        args: Annotated[Dict, Field(description="参数方案的配置。可以不填全，填需要更新的参数即可")] = None,
        pins: Annotated[Dict, Field(description="引脚配置")] = None,
    ) -> None:
        """按默认模板新增参数方案。

        ``args``/``pins`` 支持只传需要覆盖的字段；不做同名判重。

        Returns:
            None。方案追加到模型参数方案列表。

        Raises:
            ValueError: ``name`` 为空。
            TypeError: ``args`` 或 ``pins`` 非字典。
            RuntimeError: 模型未初始化。
        """
        if name is not None and (not isinstance(name, str) or not name):
            raise ValueError("name 参数必须是非空字符串或 None")
        if args is not None and not isinstance(args, dict):
            raise TypeError("args 参数必须是字典或 None")
        if pins is not None and not isinstance(pins, dict):
            raise TypeError("pins 参数必须是字典或 None")

        config = copy.deepcopy(self.project_config_init)
        if name is not None:
            config["name"] = name
        if args is not None:
            config["args"].update(args)
        if pins is not None:
            config["pins"].update(pins)
        self.project.addConfig(config)

    def add_outputs(
        self,
        job_name: Annotated[str, Field(description="计算方案的名称")],
        channels: Annotated[Dict, Field(description="需要配置的输出通道，格式为：[输出图像名称, 输出频率, 输出图像类型, 图像宽度, 输出通道key]。")],
    ) -> int:
        """向 EMTP/EMTPS 计算方案追加一组输出通道配置。

        Returns:
            int：本组配置在方案 ``output_channels`` 列表中的零基索引。

        Raises:
            ValueError: 方案不存在、类型不符，或 ``channels`` 键数不为 5。
            TypeError: ``channels`` 非字典。
        """

        if not isinstance(job_name, str) or not job_name:
            raise ValueError("job_name 参数必须是非空字符串")
        if not isinstance(channels, dict):
            raise TypeError("channels 参数必须是字典")
        if len(channels) != 5:
            raise ValueError(
                "channels 字典必须包含5个元素："
                "[输出图像名称, 输出频率, 输出图像类型, 图像宽度, 输出通道key]"
            )

        jobs = self.project.getModelJob(job_name)
        if not jobs:
            raise ValueError(f"未找到名为 '{job_name}' 的计算方案")
        job = jobs[0]
        supported_rids = {self.emtp_job_init["rid"], self.emtps_job_init["rid"]}
        if job["rid"] not in supported_rids:
            raise ValueError(f"计算方案 '{job_name}' 不是 EMTP 或 EMTPS 类型")
        job["args"]["output_channels"].append(channels)
        return len(job["args"]["output_channels"]) - 1

    def _screen_comp_by_arg(
        self,
        comp_rid: str,
        conditions: list[dict[str, Any]] | dict[str, Any] | None = None,
        comp_list: list[str] | None = None,
    ) -> dict[str, Any]:
        """按元件参数条件筛选元件。"""
        components = self.project.getComponentsByRid(comp_rid)
        if comp_list is not None:
            keys = {self._resolve_comp_key(identifier) for identifier in comp_list}
            components = {
                key: component
                for key, component in components.items()
                if key in keys
            }

        normalized_conditions = [] if conditions is None else conditions
        if isinstance(normalized_conditions, dict):
            normalized_conditions = [normalized_conditions]

        screened: dict[str, Any] = {}
        for key, component in components.items():
            matched = True
            for condition in normalized_conditions:
                value = (
                    component.label
                    if condition["arg"] == "label"
                    else self._get_numeric(component.args.get(condition["arg"], ""))
                )
                minimum = condition.get("Min")
                maximum = condition.get("Max")
                value_set = condition.get("Set")
                if minimum is not None or maximum is not None:
                    try:
                        numeric_value = float(value)
                    except (TypeError, ValueError):
                        matched = False
                        break
                    if minimum is not None and numeric_value < float(minimum):
                        matched = False
                        break
                    if maximum is not None and numeric_value > float(maximum):
                        matched = False
                        break
                if value_set is not None and value not in value_set:
                    matched = False
                    break
            if matched:
                screened[key] = component
        return screened

    def add_component_output_measures(
        self,
        job_name: Annotated[str, Field(description="仿真任务名称")],
        comp_rid: Annotated[str, Field(description="组件类型RID，如'model/CloudPSS/_newBus_3p'")],
        measured_key: Annotated[str, Field(description="【component.args的键】如'Vrms'/'P'/'Freq'等组件内部计算参数(非pins)，批量筛选组件添加量测")],
        conditions: Annotated[Optional[list], Field(description="筛选条件列表")] = None,
        comp_list: Annotated[list, Field(description="预筛选组件Key列表")] = None,
        dim: Annotated[int, Field(description="输出通道的维度,默认都是1")] = 1,
        curve_name: Annotated[str, Field(description="曲线名")] = None,
        plot_name: Annotated[str, Field(description="绘图名")] = None,
        freq: Annotated[int, Field(description="采样频率Hz")] = 200
    ) -> Annotated[dict, Field(description="筛选出的组件及输出通道索引字典")]:
        """按参数条件筛选元件，批量添加输出量测并注册到计算方案。

        每个命中元件以 ``args[measured_key]`` 当前值作为输出引脚名，
        为空时自动写入 ``#标签.曲线名``；随后建立输出通道，并在方案中
        追加一张压缩输出图统一承载这些通道。

        Returns:
            dict：``{"screenedComps": 命中组件 Key 列表,
            "output_index": 输出图配置索引}``。

        Raises:
            KeyError: 命中组件缺少 ``measured_key`` 参数。
            ValueError: 计算方案不存在或类型不符。
        """
        components = self._screen_comp_by_arg(comp_rid, conditions, comp_list)
        output_channels: list[str] = []
        curve_name = measured_key if curve_name is None else curve_name
        for component in components.values():
            pin_name = self._get_numeric(component.args[measured_key])
            if pin_name in (None, ""):
                pin_name = f"#{component.label}.{curve_name}"
                component.args[measured_key] = pin_name
            channel_id, _ = self.add_channel(str(pin_name), dim)
            output_channels.append(channel_id)

        output_index = self.add_outputs(
            job_name,
            {
                "0": plot_name,
                "1": 200 if freq is None else freq,
                "2": "compressed",
                "3": 1,
                "4": output_channels,
            },
        )
        return {"screenedComps": list(components), "output_index": output_index}

    def run_project(
        self,
        job_name: Annotated[str, Field(description="计算方案名称")],
        config_name: Annotated[str, Field(description="参数方案名称")],
        show_logs: Annotated[bool, Field(description="是否显示日志")] = False,
        api_url: Annotated[str, Field(description="API的URL")] = None,
        websocket_error_time: Annotated[float, Field(description="WebSocket错误时间")] = None,
    ) -> str | int:
        """运行指定计算方案并阻塞等待结束。

        每 10 秒轮询一次状态；启动失败自动重试至多 5 次；WebSocket
        异常且结果时间早于 ``end_time - websocket_error_time`` 时自动
        重新提交。

        Returns:
            成功返回 runner ID；平台报告失败且无法重试时返回 ``-1``。
            运行器对象保存在 ``runner`` 属性。

        Raises:
            ValueError: 计算方案或参数方案不存在。
            TypeError: 参数类型不合法。
            RuntimeError: 连续 5 次启动失败。
        """
        if not isinstance(job_name, str) or not job_name:
            raise ValueError("job_name 参数必须是非空字符串")
        if not isinstance(config_name, str) or not config_name:
            raise ValueError("config_name 参数必须是非空字符串")
        if not isinstance(show_logs, bool):
            raise TypeError("show_logs 参数必须是布尔类型")
        if api_url is not None and not isinstance(api_url, str):
            raise TypeError("api_url 参数必须是字符串或 None")
        if websocket_error_time is not None and not isinstance(
            websocket_error_time, (int, float)
        ):
            raise TypeError("websocket_error_time 参数必须是数字或 None")

        jobs = self.project.getModelJob(job_name)
        if not jobs:
            raise ValueError(f"未找到名为 '{job_name}' 的计算方案")
        configs = self.project.getModelConfig(config_name)
        if not configs:
            raise ValueError(f"未找到名为 '{config_name}' 的参数方案")

        job = jobs[0]
        config = configs[0]
        for attempt in range(5):
            try:
                run_options = {"job": job, "config": config}
                if api_url is not None:
                    run_options["apiUrl"] = api_url
                self.runner = self.project.run(**run_options)
                break
            except Exception as error:
                if not isinstance(
                    error, (ConnectionError, TimeoutError, OSError, RuntimeError)
                ):
                    raise
                if attempt == 4:
                    raise RuntimeError("启动仿真失败，已重试 5 次") from error
                print(f"Start runner failed, restarting...{error}")
                time.sleep(60)

        simulation_rids = {self.emtp_job_init["rid"], self.emtps_job_init["rid"]}
        is_transient_simulation = job["rid"] in simulation_rids
        end_time = (
            float(job["args"]["end_time"])
            if is_transient_simulation
            else None
        )
        start_time = time.time()

        while True:
            status = self.runner.status()
            if status >= 1:
                return self.runner.id
            if status == -1:
                print("仿真出错了，可能是 WebSocket 问题。")
                if websocket_error_time is not None and is_transient_simulation:
                    try:
                        current_time = self._get_result_end_time()
                    except (IndexError, KeyError, TypeError, ValueError):
                        current_time = None
                    should_retry = (
                        current_time is None
                        or current_time < end_time - websocket_error_time
                    )
                    if should_retry:
                        current_text = (
                            "None" if current_time is None else str(round(current_time, 2))
                        )
                        print(f"准备重新运行仿真。Current Time：{current_text}")
                        time.sleep(15)
                        return self.run_project(
                            job_name,
                            config_name,
                            show_logs,
                            api_url,
                            websocket_error_time,
                        )
                return -1

            if show_logs:
                for log in self.get_runner_logs():
                    content = log.get("data", {}).get("content")
                    if content is not None:
                        print(content)

            elapsed = time.time() - start_time
            if is_transient_simulation:
                try:
                    current_time = self._get_result_end_time()
                except (IndexError, KeyError, TypeError, ValueError):
                    current_time = None
            else:
                current_time = None
            if current_time is not None:
                progress = current_time / end_time * 100 if end_time > 0 else 0
                print(
                    f"Progress: {round(current_time, 2)}s / {end_time}s "
                    f"({progress:.1f}%). Time cost: {elapsed:.1f}s. "
                    f"Runner Status: {status}"
                )
                if round(current_time, 2) >= end_time:
                    return self.runner.id
            else:
                print(f"Time cost: {elapsed:.1f}s. Runner Status: {status}")
            time.sleep(10)

    def _get_result_end_time(self) -> float | None:
        """返回第一张结果图当前的最后时刻；结果尚未生成时返回 ``None``。"""
        channel_names = self.runner.result.getPlotChannelNames(0)
        if not channel_names:
            return None
        data = self.runner.result.getPlotChannelData(0, channel_names[0])
        x_values = data.get("x", [])
        return float(x_values[-1]) if x_values else None

    def get_runner_logs(self) -> list[dict[str, Any]]:
        """读取当前运行器的日志。

        Returns:
            日志字典列表；未运行过方案时返回空列表。

        Raises:
            RuntimeError: 结果服务不可用时由底层 SDK 抛出。
        """
        runner = getattr(self, "runner", None)
        if runner is None:
            return []
        return runner.result.getLogs()

    def plot_result(
        self,
        result: Annotated[
            Any, Field(description="仿真结果对象或结果 ID；省略时使用当前 runner 的结果")
        ] = None,
        k: Annotated[int | None, Field(description="要绘制的结果图索引")] = None,
        html_path: Annotated[
            str | os.PathLike[str] | None,
            Field(description="Plotly HTML 输出路径；为 None 时不保存"),
        ] = None,
        show: Annotated[
            bool, Field(description="是否显示图形；批处理时可设为 False")
        ] = True,
        timestamp: Annotated[
            str | None,
            Field(description="保存文件使用的统一时间戳；未指定时自动生成"),
        ] = None,
    ) -> Any:
        """绘制一张仿真结果图，可保存为带时间戳的 Plotly HTML。

        Returns:
            Plotly 模式返回 ``Figure``，Matplotlib 模式返回 ``Axes``；
            保存后路径记录在 ``last_plot_html_path``。

        Raises:
            TypeError: ``show`` 非布尔值。
            ValueError: ``k`` 非法、结果 ID 为空或绘图工具不支持。
            RuntimeError: 无可用结果或结果未成功完成。
        """
        if not isinstance(show, bool):
            raise TypeError("show 参数必须是布尔类型")
        if k is not None and (not isinstance(k, int) or isinstance(k, bool) or k < 0):
            raise ValueError("k 参数必须是非负整数或 None")

        if result is None:
            runner = getattr(self, "runner", None)
            if runner is None:
                raise RuntimeError("Runner 未初始化，且未提供仿真结果")
            result = runner.result
        elif isinstance(result, str):
            if not result:
                raise ValueError("结果 ID 不能为空字符串")
            from cloudpss.job.job import Job

            result_job = Job.fetch(result)
            if result_job.status() != 1:
                raise RuntimeError(
                    f"仿真结果尚未成功完成，当前状态={result_job.status()}"
                )
            result = result_job.result

        plot_index = 0 if k is None else k
        channel_names = result.getPlotChannelNames(plot_index)

        if self.config["plot_tool"] == "plotly":
            figure = go.Figure()
            for channel_name in channel_names:
                data = result.getPlotChannelData(plot_index, channel_name)
                figure.add_trace(
                    go.Scatter(x=data["x"], y=data["y"], mode="lines", name=channel_name)
                )
            figure.update_layout(
                title=result.getPlot(plot_index)["data"]["title"],
                xaxis_title="Time / s",
                yaxis_title="Value",
            )
            if html_path is not None:
                output_path = self._timestamped_file_path(html_path, timestamp)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                figure.write_html(str(output_path), include_plotlyjs=True)
                self.last_plot_html_path = str(output_path)
            if show:
                figure.show()
            return figure

        if self.config["plot_tool"] == "matplotlib":
            figure, axes = plt.subplots(figsize=(6, 3))
            axes.set_title(result.getPlot(plot_index)["data"]["title"])
            for channel_name in channel_names:
                data = result.getPlotChannelData(plot_index, channel_name)
                axes.plot(data["x"], data["y"], label=channel_name)
            axes.set_xlabel("Time / s")
            axes.set_ylabel("Value")
            axes.legend()
            if show:
                plt.show()
            return axes

        raise ValueError(f"不支持的绘图工具: {self.config['plot_tool']}")

    @staticmethod
    def _timestamped_file_path(
        path: str | os.PathLike[str], timestamp: str | None = None
    ) -> Path:
        """为输出文件名添加统一时间戳。"""
        output_path = Path(path)
        timestamp_text = timestamp or time.strftime("%Y_%m_%d_%H_%M_%S")
        if not output_path.stem.endswith(f"_{timestamp_text}"):
            output_path = output_path.with_name(
                f"{output_path.stem}_{timestamp_text}{output_path.suffix}"
            )
        return output_path

    @staticmethod
    def _resolve_local_save_root(save_path: str | os.PathLike[str] | None = None) -> Path:
        """解析本地结果根目录；显式路径优先，未指定时默认为项目根目录/results。"""
        project_root = Path(__file__).resolve().parents[2]
        configured_root = Path(save_path) if save_path is not None else Path("results")
        return (
            configured_root
            if configured_root.is_absolute()
            else project_root / configured_root
        ).resolve()

    def _ensure_run_context(
        self,
        timestamp: str | None = None,
        save_path: str | os.PathLike[str] | None = None,
        run_id: str | None = None,
    ) -> tuple[str, Path]:
        """创建或复用本次分析的唯一结果目录。"""
        if self.run_dir is not None and self.run_id is not None:
            return self.run_id, self.run_dir
        timestamp_text = timestamp or time.strftime("%Y%m%d_%H%M%S")
        if run_id is None:
            run_id = f"{timestamp_text}_{uuid.uuid4().hex[:8]}"
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", run_id):
            raise ValueError("run_id 只能包含字母、数字、下划线、连字符和点")
        save_root = self._resolve_local_save_root(save_path)
        project_key = str(self.config["model"])
        run_dir = save_root / project_key / "runs" / run_id
        (run_dir / "plots").mkdir(parents=True, exist_ok=True)
        (run_dir / "data").mkdir(parents=True, exist_ok=True)
        self.run_id = run_id
        self.run_dir = run_dir
        return run_id, run_dir

    @staticmethod
    def _get_numeric(value: Any) -> Any:
        """读取 CloudPSS 参数值，兼容普通值和表达式字典。"""
        if not isinstance(value, dict):
            return value
        for key in ("source", "value", "Value", "default", "Default"):
            if key in value:
                return value[key]
        return ""

    @classmethod
    def _get_float(cls, value: Any, default: float | None = None) -> float:
        """将 CloudPSS 参数安全转换为浮点数。"""
        numeric_value = cls._get_numeric(value)
        if numeric_value in (None, ""):
            if default is not None:
                return default
            raise ValueError("CloudPSS 参数为空，无法转换为浮点数")
        return float(numeric_value)

    @classmethod
    def _get_int(cls, value: Any, default: int | None = None) -> int:
        """将 CloudPSS 参数安全转换为整数。"""
        numeric_value = cls._get_numeric(value)
        if numeric_value in (None, ""):
            if default is not None:
                return default
            raise ValueError("CloudPSS 参数为空，无法转换为整数")
        return int(float(numeric_value))

    def _resolve_comp_key(self, identifier: str) -> str:
        """``resolve_component_key`` 的内部别名，供工具箱内部调用。"""
        return self.resolve_component_key(identifier)

    def _set_breaker_3p(
        self,
        bus_pin_name_1: str,
        bus_pin_name_2: str,
        ctrl_sig_name: str,
        other_paras: dict[str, Any] | None = None,
    ) -> dict[str, str]:
        """在两个引脚之间添加三相断路器。"""
        args = {
            "Name": "SA_三相断路器",
            "ctrlsignal": ctrl_sig_name,
            "Init": "1",
            "Status": "",
        }
        if other_paras:
            args.update(other_paras)
        component_id, label = self.add_comp_in_canvas(
            "model/CloudPSS/_newBreaker_3p",
            canvas=self.c_fid,
            args=args,
            pins={"0": bus_pin_name_1, "1": bus_pin_name_2},
            label="SA_三相断路器",
        )
        return {"id1": component_id, "label": label}

    def _set_ground_fault(
        self,
        pin_name: str,
        fault_start_time: float = 4,
        fault_end_time: float = 4.09,
        fault_type_index: int = 7,
        other_paras: dict[str, Any] | None = None,
    ) -> dict[str, str]:
        """在指定引脚添加接地故障元件。"""
        args = {
            "Name": "SA_接地故障",
            "fs": str(fault_start_time),
            "fe": str(fault_end_time),
            "ft": str(fault_type_index),
        }
        if other_paras:
            args.update(other_paras)
        component_id, label = self.add_comp_in_canvas(
            "model/CloudPSS/_newFaultResistor_3p",
            canvas=self.c_fid,
            args=args,
            pins={"0": pin_name, "1": "GND"},
            label="SA_接地故障",
        )
        return {"id1": component_id, "label": label}

    def _set_n_1(
        self,
        trans_id: str,
        cut_time: float | list[float],
        other_breaker_paras: dict[str, Any] | None = None,
    ) -> None:
        """通过线路两端断路器设置 N-1 切除。"""
        trans_key = self._resolve_comp_key(trans_id)
        trans_comp = self.project.getComponentByKey(trans_key)
        original_pins = trans_comp.pins.copy()
        trans_name = str(
            self._get_numeric(trans_comp.args.get("Name"))
            or trans_comp.label
            or trans_key
        )
        trans_comp.pins["0"] = f"BreakerPin_{trans_name}_0"
        trans_comp.pins["1"] = f"BreakerPin_{trans_name}_1"
        signal_name = f"@Sig_Breaker_{trans_name}"

        cut_times = cut_time if isinstance(cut_time, list) else [cut_time]
        if len(cut_times) not in (1, 2):
            raise ValueError("cut_time 必须为数值或包含两个时间的列表")
        signals = [signal_name] if len(cut_times) == 1 else [signal_name + "1", signal_name + "2"]
        self._set_breaker_3p(
            trans_comp.pins["0"], original_pins["0"], signals[0], other_breaker_paras
        )
        self._set_breaker_3p(
            trans_comp.pins["1"], original_pins["1"], signals[-1], other_breaker_paras
        )
        for signal, current_cut_time in zip(signals, cut_times):
            self.add_comp_in_canvas(
                "model/CloudPSS/_newStepGen",
                canvas=self.c_fid,
                args={
                    "Name": "阶跃信号",
                    "V0": "1",
                    "V1": "0",
                    "Time": str(current_cut_time),
                },
                pins={"0": signal},
                label="阶跃信号",
            )
        self.new_line_position(self.c_fid)

    def _add_ground_fault_at_position(
        self,
        trans_comp: Any,
        side: float,
        fault_start_time: float,
        fault_type_index: int,
        other_fault_paras: dict[str, Any] | None = None,
    ) -> None:
        """在线路指定端点或中间位置添加接地故障。"""
        if 1e-10 < side < 1 - 1e-10:
            component = Component(copy.deepcopy(trans_comp.toJSON()))
            component.position["x"] += 10
            component.position["y"] -= 10
            component.id += "_addFault"
            component.pins["0"] = component.pins["1"]
            component.pins["1"] = component.id + "_TempPin"
            length = self._get_float(trans_comp.args["Length"])
            component.args["Length"] = str(length * (1 - side))
            component.args["ModelType"] = "0"
            component.args["Decoupled"] = "0"
            component.label += "_Opp"
            self.project.revision.implements.diagram.cells[component.id] = component

            trans_comp.args["Length"] = str(length * side)
            trans_comp.pins["1"] = component.id + "_TempPin"
            trans_comp.args["ModelType"] = "0"
            trans_comp.args["Decoupled"] = "0"
            fault_pin = trans_comp.pins["1"]
        else:
            fault_pin = trans_comp.pins[str(int(round(side)))]
        self._set_ground_fault(
            fault_pin,
            fault_start_time,
            FAULT_PERMANENT_END_TIME,
            fault_type_index,
            other_fault_paras,
        )

    def set_n_1_ground_fault(
        self,
        trans_key: Annotated[str, Field(description="传输元件的实例 key 或显示 label；label 重复时报错并列出候选 key，需选择后重新传入")],
        side: Annotated[float, Field(description="故障发生在线路上的位置：0 首端，1 末端，(0,1) 中间比例，默认0", ge=0, le=1)] = 0.0,
        fault_start_time: Annotated[float, Field(description="故障开始时间，默认4", ge=0)] = 4.0,
        cut_time: Annotated[float, Field(description="线路切除时间，默认4.06", ge=0)] = 4.06,
        fault_type_index: Annotated[int, Field(description="故障类型索引：0 无故障，1-7 分别对应 A、B、C、AB、BC、AC、ABC 相故障,默认7", ge=0, le=7)] = 7,
        other_breaker_paras: Annotated[dict, Field(description="其他断路器参数字典，增量覆盖默认的 Name、ctrlsignal、Init、Status")] = None,
        other_fault_paras: Annotated[dict, Field(description="其他故障电阻参数字典。可选 key 为 Init、chg、fct、I、V，分别表示初始电阻、故障期间电阻、故障清除时刻、三相电阻故障电流、三相电阻故障电压")] = None,
    ) -> dict[str, Any]:
        """设置 N-1 场景：线路两端断路器切除叠加指定位置接地故障。

        接地故障自 ``fault_start_time`` 起按永久故障处理；``side`` 在
        (0,1) 开区间时线路拆分为两段并在拆分点施加故障。``cut_time``
        也可传双元素列表，分别指定两端断路器的切除时刻。``trans_key``
        由 :meth:`resolve_component_key` 解析，可传实例 key 或 label。

        Returns:
            dict：``{"result": "故障设置完成", "transKey": 解析后的元件
            Key, "side": 故障位置, "fault_start_time": 故障开始时间,
            "cut_time": 切除时间, "fault_type": 故障类型索引}``。

        Raises:
            ValueError: ``side`` 越界、``cut_time`` 格式不合法，或
                ``trans_key`` 的 label 对应多个元件。
            KeyError: ``trans_key`` 无法解析为模型中的元件。
        """
        if not 0 <= side <= 1:
            raise ValueError("side 必须在 0 到 1 之间")
        resolved_key = self._resolve_comp_key(trans_key)
        self._set_n_1(resolved_key, cut_time, other_breaker_paras)
        self._add_ground_fault_at_position(
            self.project.getComponentByKey(resolved_key),
            side,
            fault_start_time,
            fault_type_index,
            other_fault_paras,
        )
        return {
            "result": "故障设置完成",
            "transKey": resolved_key,
            "side": side,
            "fault_start_time": fault_start_time,
            "cut_time": cut_time,
            "fault_type": fault_type_index,
        }

    def _get_bus_all_keys(self) -> list[str]:
        """获取全部三相母线 key。"""
        return list(self.project.getComponentsByRid("model/CloudPSS/_newBus_3p"))

    def _get_generator_all_keys(self) -> list[str]:
        """获取潮流采样涉及的全部发电元件 key。"""
        keys: list[str] = []
        for rid in (
            "model/CloudPSS/SyncGeneratorRouter",
            "model/CloudPSS/_newACVoltageSource_3p",
            "model/CloudPSS/WGSource",
            "model/CloudPSS/PVStation",
        ):
            keys.extend(self.project.getComponentsByRid(rid))
        return keys

    def _get_load_all_keys(self) -> list[str]:
        """获取全部三相指数负荷 key。"""
        return list(self.project.getComponentsByRid("model/CloudPSS/_newExpLoad_3p"))

    def _get_acline_all_keys(self) -> list[str]:
        """获取全部交流线路 key。"""
        return list(self.project.getComponentsByRid("model/CloudPSS/TransmissionLine"))

    def _get_transformer_all_keys(self) -> list[str]:
        """获取全部两绕组和三绕组变压器 key。"""
        keys: list[str] = []
        for rid in (
            "model/CloudPSS/_newTransformer_3p2w",
            "model/CloudPSS/_newTransformer_3p3w",
        ):
            keys.extend(self.project.getComponentsByRid(rid))
        return keys

    def _get_power_flow_settings(self) -> list[list[Any]]:
        """读取发电机与负荷的当前潮流设置。"""
        settings: list[list[Any]] = []
        for key in self.gen_keys:
            component = self.project.getComponentByKey(key)
            if component.definition == "model/CloudPSS/PVStation":
                settings.append(
                    [
                        key,
                        "PV_station",
                        self._get_float(component.args.get("PG0"), 0.0),
                        self._get_float(component.args.get("QG0"), 0.0),
                    ]
                )
                continue
            bus_type = self._get_int(component.args.get("BusType"), 0)
            if bus_type == 0:
                settings.append(
                    [
                        key,
                        "gen_PQ",
                        self._get_float(component.args.get("pf_P"), 0.0),
                        self._get_float(component.args.get("pf_Q"), 0.0),
                    ]
                )
            elif bus_type == 1:
                settings.append(
                    [
                        key,
                        "gen_PV",
                        self._get_float(component.args.get("pf_P"), 0.0),
                        self._get_float(component.args.get("pf_V"), 1.0),
                    ]
                )
            elif bus_type == 2:
                settings.append(
                    [
                        key,
                        "gen_slack",
                        self._get_float(component.args.get("pf_V"), 1.0),
                        self._get_float(component.args.get("pf_Theta"), 0.0),
                    ]
                )
        for key in self.load_keys:
            component = self.project.getComponentByKey(key)
            settings.append(
                [
                    key,
                    "load",
                    self._get_float(component.args.get("p"), 0.0),
                    self._get_float(component.args.get("q"), 0.0),
                ]
            )
        return settings

    def _set_power_flow_settings(self, settings: list[list[Any]]) -> None:
        """按 ``_get_power_flow_settings`` 的格式回写潮流设置。"""
        arg_names = {
            "gen_PQ": ("pf_P", "pf_Q"),
            "gen_PV": ("pf_P", "pf_V"),
            "gen_slack": ("pf_V", "pf_Theta"),
            "PV_station": ("PG0", "QG0"),
            "load": ("p", "q"),
        }
        for key, setting_type, first, second in settings:
            first_arg, second_arg = arg_names[setting_type]
            component = self.project.getComponentByKey(key)
            component.args[first_arg] = first
            component.args[second_arg] = second

    def _get_bus_all_pf_result(self) -> list[list[Any]]:
        """读取潮流结果中的母线数据。"""
        columns = self.runner.result.getBuses()[0]["data"]["columns"]
        return [
            list(row)
            for row in zip(*(columns[index]["data"] for index in range(6)))
        ]

    def _get_acline_all_pf_result(self) -> list[list[Any]]:
        """读取潮流结果中的交流线路数据。"""
        columns = self.runner.result.getBranches()[0]["data"]["columns"]
        order = (0, 1, 4, 2, 3, 5, 6)
        return [
            list(row)
            for row in zip(*(columns[index]["data"] for index in order))
        ]

    def _get_power_flow_sample_simple_random(
        self,
        flow_job_name: str,
        flow_config_name: str,
        seed: int | None = None,
        low: float = 1.0,
        high: float = 1.0,
        v_low: float = 1.0,
        v_high: float = 1.0,
        adjust_probability: float = 0.1,
    ) -> list[list[Any]]:
        """生成一组随机潮流样本并将收敛结果回写模型。"""
        rng = np.random.default_rng(seed)
        for _ in range(MAX_POWER_FLOW_RETRIES):
            self._set_power_flow_settings(self.initial_pf_setting)
            for setting in self.initial_pf_setting:
                component = self.project.getComponentByKey(setting[0])
                factor = low + (high - low) * rng.random()
                if component.definition == "model/CloudPSS/WGSource":
                    wt_num = self._get_float(component.args["WT_Num"])
                    component.args["pf_P"] = 1.5 * wt_num * rng.random()
                elif setting[1] == "PV_station":
                    component.args["PG0"] = setting[2] * factor
                    component.args["QG0"] = setting[3] * factor
                elif setting[1] == "gen_PQ":
                    component.args["pf_P"] = setting[2] * factor
                    component.args["pf_Q"] = setting[3] * factor
                elif setting[1] == "gen_PV":
                    component.args["pf_P"] = setting[2] * factor
                    if 0.95 <= setting[3] <= 1.05 and rng.random() < adjust_probability:
                        component.args["pf_V"] = min(
                            max(setting[3] * (v_low + (v_high - v_low) * rng.random()), 0.95),
                            1.05,
                        )
                elif setting[1] == "load":
                    component.args["p"] = setting[2] * factor
                    component.args["q"] = setting[3] * factor
            try:
                self.run_project(flow_job_name, flow_config_name)
                self.runner.result.powerFlowModify(self.project)
            except (ConnectionError, TimeoutError, OSError, RuntimeError):
                continue
            return self._get_power_flow_settings()
        raise RuntimeError(f"潮流计算失败，已重试 {MAX_POWER_FLOW_RETRIES} 次")

    def _get_gen_ph_p(self, bus_result: list[list[Any]]) -> bool:
        """校验母线电压和平衡机有功、无功限制。"""
        slack_key = None
        slack_label = None
        slack_component = None
        for key in self.gen_keys:
            component = self.project.getComponentByKey(key)
            if self._get_int(component.args.get("BusType"), -1) == 2:
                slack_key = key
                slack_label = component.label
                slack_component = component
                break
        if slack_component is None:
            return False
        p_max = self._get_float(slack_component.args["Smva"])
        q_min = self._get_float(slack_component.args["pf_Qmin"])
        q_max = self._get_float(slack_component.args["pf_Qmax"])
        for row in bus_result:
            if not 0.90 <= float(row[2]) <= 1.10:
                return False
            if row[1] in (slack_key, slack_label) and not (
                float(row[4]) <= p_max and q_min <= float(row[5]) <= q_max
            ):
                return False
        return True

    def power_flow_sample_simple_random(
        self,
        flow_job_name: Annotated[str, Field(description="潮流计算方案名称")],
        flow_config_name: Annotated[str, Field(description="潮流计算参数方案")],
        p_low: Annotated[float, Field(description="随机化参数的下限乘数")] = 1.0,
        p_high: Annotated[float, Field(description="随机化参数的上限乘数")] = 1.0,
        v_low:  Annotated[float, Field(description="PV型发电机电压随机化的下限乘数")] = 1.0,
        v_high:  Annotated[float, Field(description="PV型发电机电压随机化的上限乘数")] = 1.0,
        v_adjust_ratio: Annotated[float, Field(description="随机调整PV型发电机电压的概率")] =  0.1,
    ) -> Dict[str, Any]:
        """生成一个随机潮流样本，校验收敛性并回写模型。

        以初始潮流设置为基准随机化发电机出力与负荷；不收敛时自动
        重采样（至多重试 ``PSA_MAX_POWER_FLOW_RETRIES`` 次）。完整采样
        数据保存在 ``pf_result`` 属性。内部异常不抛出，经返回值传递。

        Returns:
            dict：``status`` 为 ``"success"``（附带 ``P_low``/``P_high``）、
            ``"failed"``（附带 ``message``）或 ``"error"``（附带
            ``error_message``）。
        """
        try:
            settings = self._get_power_flow_sample_simple_random(
                flow_job_name,
                flow_config_name,
                seed=random.randint(1, 999999),
                low=p_low,
                high=p_high,
                v_low=v_low,
                v_high=v_high,
                adjust_probability=v_adjust_ratio,
            )
            bus_result = self._get_bus_all_pf_result()
            acline_result = self._get_acline_all_pf_result()
            self.pf_result = {
                "status": "success" if self._get_gen_ph_p(bus_result) else "failed",
                "pf_setting": [row[2:] for row in settings],
                "bus_result": [row[2:] for row in bus_result],
                "acline_result": [row[3:] for row in acline_result],
            }
            if self.pf_result["status"] == "failed":
                return {"status": "failed", "message": "潮流未收敛"}
            return {"status": "success", "P_low": p_low, "P_high": p_high}
        except Exception as error:
            self.pf_result = {"status": "error", "error_message": str(error)}
            return self.pf_result.copy()

    @staticmethod
    def _write_flow_hdf5(
        target: Path,
        p_low: float,
        p_high: float,
        pf_setting: list[Any],
        bus_result: list[Any],
        acline_result: list[Any],
        append: bool = False,
    ) -> None:
        """写入潮流 HDF5 数据。"""
        try:
            import h5py
        except ImportError as error:
            raise RuntimeError("保存 HDF5 结果需要安装 h5py") from error

        mode = "a" if append and target.exists() else "w"
        with h5py.File(target, mode) as hdf5_file:
            _create_or_append_hdf5_dataset(
                hdf5_file, "P_low", np.asarray([p_low])
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "P_high", np.asarray([p_high])
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "pf_setting", np.asarray(pf_setting)
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "bus_result", np.asarray(bus_result)
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "acline_result", np.asarray(acline_result)
            )

    @staticmethod
    def _write_emt_hdf5(
        target: Path,
        initial_state: list[Any],
        bus_voltage_data: np.ndarray,
        power_data: np.ndarray,
        frequency_data: np.ndarray,
        power_angle_data: np.ndarray,
        append: bool = False,
    ) -> None:
        """写入电磁暂态 HDF5 数据。"""
        try:
            import h5py
        except ImportError as error:
            raise RuntimeError("保存 HDF5 结果需要安装 h5py") from error

        mode = "a" if append and target.exists() else "w"
        with h5py.File(target, mode) as hdf5_file:
            _create_or_append_hdf5_dataset(
                hdf5_file, "initial_state", np.asarray([initial_state])
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "bus_voltage_data", np.asarray([bus_voltage_data])
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "power_data", np.asarray([power_data])
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "frequency_data", np.asarray([frequency_data])
            )
            _create_or_append_hdf5_dataset(
                hdf5_file, "power_angle_data", np.asarray([power_angle_data])
            )

    def save_flow_emt_hdf5(
        self,
        trans_id: Annotated[str, Field(description="故障所在的传输元件标识符")] = None,
        side: Annotated[float, Field(description="故障发生在线路上的位置")] = None,
        fault_start_time: Annotated[float, Field(description="故障开始时间")] = None,
        cut_time: Annotated[float, Field(description="故障切除时间")] = None,
        fault_type_index: Annotated[int, Field(description="故障类型索引")] = None,
        P_low: Annotated[float, Field(description="当前仿真负荷区间的下限")] = 1.0,
        P_high: Annotated[float, Field(description="当前仿真负荷区间的上限")] = 1.0,
        timestamp: Annotated[str | None, Field(description="保存文件使用的统一时间戳；未指定时自动生成")] = None,
        save_path: Annotated[str | os.PathLike[str] | None, Field(description="本地结果根目录；未指定时使用项目根目录/results")] = None,
        run_id: Annotated[str | None, Field(description="本次分析唯一标识；未指定时自动生成")] = None,
    ) -> dict[str, str]:
        """将当前工况的潮流与暂态结果分别保存为 HDF5。

        前置条件：已完成潮流采样和一次成功的暂态仿真（结果不少于
        4 张图）。每次运行写入项目根目录 results/{model}/runs/{run_id}/
        下的 data/flow_result.h5 和 data/emt_result.h5；
        批量模式（is_batch_mode）下按首维追加。

        Returns:
            dict：``{"flow_url": 潮流文件绝对路径, "emt_url": 暂态文件
            绝对路径}``。

        Raises:
            ValueError: 必填参数缺失，或无可保存的潮流/暂态结果。
            RuntimeError: 暂态结果少于 4 张图或数据格式异常。
        """
        required_values = {
            "trans_id": trans_id,
            "side": side,
            "fault_start_time": fault_start_time,
            "cut_time": cut_time,
            "fault_type_index": fault_type_index,
            "P_low": P_low,
            "P_high": P_high,
        }
        missing = [name for name, value in required_values.items() if value is None]
        if missing:
            raise ValueError(
                "[save_flow_emt_hdf5] 缺少必要参数: " + ", ".join(missing)
            )
        if not self.pf_result:
            raise ValueError("[save_flow_emt_hdf5] 尚无可保存的潮流计算结果")

        flow_status = self.pf_result.get("status")
        if flow_status == "failed":
            flow_category = "fail"
        elif flow_status == "success":
            flow_category = "pass"
        else:
            raise ValueError(f"未知的潮流状态: {flow_status}")

        if self.runner is None or getattr(self.runner, "result", None) is None:
            raise ValueError("[save_flow_emt_hdf5] 尚无可保存的暂态仿真结果")
        plots = list(self.runner.result.getPlots())
        if len(plots) < 4:
            raise RuntimeError("仿真结果少于四张输出图，无法保存暂态数据")

        def get_plot_data(index: int) -> np.ndarray:
            try:
                traces = plots[index]["data"]["traces"]
                return np.asarray([trace["y"] for trace in traces])
            except (KeyError, TypeError, IndexError) as error:
                raise RuntimeError(f"第 {index + 1} 张输出图的数据格式不正确") from error

        bus_voltage_data = get_plot_data(0)
        power_data = get_plot_data(1)
        frequency_data = get_plot_data(2) * 50
        power_angle_data = get_plot_data(3)
        initial_state = [
            trans_id,
            side,
            fault_start_time,
            cut_time,
            fault_type_index,
        ]

        timestamp_text = timestamp or time.strftime("%Y%m%d_%H%M%S")
        actual_run_id, run_dir = self._ensure_run_context(
            timestamp=timestamp_text,
            save_path=save_path,
            run_id=run_id,
        )
        local_flow_path = (run_dir / "data" / "flow_result.h5").resolve()
        local_emt_path = (run_dir / "data" / "emt_result.h5").resolve()

        local_flow_path.parent.mkdir(parents=True, exist_ok=True)
        local_emt_path.parent.mkdir(parents=True, exist_ok=True)
        self._write_flow_hdf5(
            local_flow_path,
            P_low,
            P_high,
            [self.pf_result["pf_setting"]],
            [self.pf_result["bus_result"]],
            [self.pf_result["acline_result"]],
            append=self.is_batch_mode,
        )
        self._write_emt_hdf5(
            local_emt_path,
            initial_state,
            bus_voltage_data,
            power_data,
            frequency_data,
            power_angle_data,
            append=self.is_batch_mode,
        )
        return {
            "flow_url": str(local_flow_path),
            "emt_url": str(local_emt_path),
            "flow_status": flow_category,
            "run_id": actual_run_id,
            "run_dir": str(run_dir.resolve()),
        }

    def get_transmission_keys(self) -> dict[str, list[str]]:
        """返回全部传输元件 key 的拷贝，供批量场景构建与只读探查使用。

        Returns:
            dict：``{"acline_keys": 交流线路 key 列表,
            "trans_keys": 变压器 key 列表}``，均为内部列表的拷贝。
        """
        return {
            "acline_keys": list(self.acline_keys),
            "trans_keys": list(self.trans_keys),
        }

    def generate_random_fault_params(
        self,
        seed: Annotated[
            int | None,
            Field(description="随机种子；指定后使用独立随机源，不影响全局随机状态"),
        ] = None,
    ) -> dict[str, Any]:
        """随机生成一组 N-1 接地故障参数，不修改模型。

        从全部交流线路和变压器中随机选择故障元件；``side`` 在首端/末端
        中随机，``fault_start_time`` 固定 3.0 秒，``cut_time`` 在故障后
        0.08~0.2 秒内均匀取值，``fault_type`` 固定为 7（三相接地短路）。

        Returns:
            dict：``transKey``/``side``/``fault_start_time``/``cut_time``/
            ``fault_type``，键名与 :meth:`set_n_1_ground_fault` 参数对应。

        Raises:
            RuntimeError: 模型中没有交流线路或变压器。
        """
        candidates = [*self.acline_keys, *self.trans_keys]
        if not candidates:
            raise RuntimeError("当前模型没有可用于 N-1 故障的线路或变压器")
        rng = random.Random(seed) if seed is not None else random
        fault_start_time = 3.0
        return {
            "transKey": rng.choice(candidates),
            "side": rng.choice([0, 1]),
            "fault_start_time": fault_start_time,
            "cut_time": round(fault_start_time + rng.uniform(0.08, 0.2), 2),
            "fault_type": 7,
        }

    @staticmethod
    def check_voltage(
        bus_voltage_data: Annotated[np.ndarray, Field(description="母线电压矩阵（p.u.），形状 [母线数, 采样点数]")],
        step_time: Annotated[float, Field(description="仿真步长（秒）")],
    ) -> bool:
        """校验不存在持续 1 秒及以上的低电压。

        Returns:
            bool：任一母线电压低于 0.7 p.u. 且持续达到 1.0 秒时返回
            ``False``，否则返回 ``True``。
        """
        for voltage in bus_voltage_data:
            below_threshold_time = 0.0
            for value in voltage:
                below_threshold_time = (
                    below_threshold_time + step_time if value < 0.7 else 0.0
                )
                if below_threshold_time >= 1.0:
                    return False
        return True

    @staticmethod
    def check_frequency(
        frequency_data: Annotated[np.ndarray, Field(description="频率矩阵（Hz），形状 [机组数, 采样点数]")],
    ) -> bool:
        """校验频率全程位于 49~51 Hz。

        Returns:
            bool：任一采样点越界返回 ``False``，否则返回 ``True``。
        """
        return bool(np.all((frequency_data >= 49) & (frequency_data <= 51)))

    @staticmethod
    def check_power_angle_diff(
        power_angle_data: Annotated[np.ndarray, Field(description="功角矩阵（度），形状 [机组数, 采样点数]")],
    ) -> bool:
        """校验任意两台机组同一时刻的功角差不超过 360°。

        Returns:
            bool：超限返回 ``False``；机组数少于 2 时直接返回 ``True``。
        """
        if len(power_angle_data) < 2:
            return True
        return all(
            np.max(np.abs(power_angle_data[index] - power_angle_data[other])) <= 360
            for index in range(len(power_angle_data))
            for other in range(index + 1, len(power_angle_data))
        )

    def extract_and_check_data(
        self,
        job_name: Annotated[str, Field(description="仿真计算方案名称")],
        timestamp: Annotated[str, Field(description="保存时间戳")] = None,
        show_plots: Annotated[bool, Field(description="是否显示图表")] = True,
        save_path: Annotated[str | os.PathLike[str] | None, Field(description="本地结果根目录；未指定时使用项目根目录/results")] = None,
        run_id: Annotated[str | None, Field(description="本次分析唯一标识；未指定时自动生成")] = None,
    ) -> dict[str, Any]:
        """提取暂态稳定性数据、执行三项稳定校验并保存四张结果图。

        要求当前 ``runner`` 的结果包含固定顺序的 4 张图：母线电压、
        发电机功率、发电机转速、发电机功角；校验项为电压、频率、功角
        差。图保存为 HTML 到本次运行目录 results/{model}/runs/{run_id}/plots/。

        Returns:
            dict：``voltage_ok``/``frequency_ok``/``power_angle_ok``
            （bool）三项校验结论、``plots``（图对象列表）和
            ``html_files``（``{图名: HTML 路径}``）。

        Raises:
            RuntimeError: 结果少于 4 张图。
            ValueError: 找不到指定的计算方案。
        """
        plots = list(self.runner.result.getPlots())
        if len(plots) < 4:
            raise RuntimeError("仿真结果少于四张输出图，请按既定顺序添加量测")
        voltage_data = np.array([trace["y"] for trace in plots[0]["data"]["traces"]])
        frequency_data = (
            np.array([trace["y"] for trace in plots[2]["data"]["traces"]]) * 50
        )
        angle_data = np.array([trace["y"] for trace in plots[3]["data"]["traces"]])
        jobs = self.project.getModelJob(job_name)
        if not jobs:
            raise ValueError(f"未找到名为 '{job_name}' 的计算方案")
        step_time = float(jobs[0]["args"]["step_time"])
        result = {
            "voltage_ok": self.check_voltage(voltage_data, step_time),
            "frequency_ok": self.check_frequency(frequency_data),
            "power_angle_ok": self.check_power_angle_diff(angle_data),
        }
        timestamp_text = timestamp or time.strftime("%Y%m%d_%H%M%S")
        actual_run_id, run_dir = self._ensure_run_context(
            timestamp=timestamp_text,
            save_path=save_path,
            run_id=run_id,
        )
        html_dir = (run_dir / "plots").resolve()
        plot_names = (
            "BusVoltage",
            "GeneratorPower",
            "GeneratorSpeed",
            "GeneratorAngle",
        )
        figures = []
        html_files: dict[str, str] = {}
        for index, plot_name in enumerate(plot_names):
            figure = self.plot_result(
                k=index,
                html_path=html_dir / f"{plot_name}.html",
                show=show_plots,
                timestamp=timestamp_text,
            )
            figures.append(figure)
            if self.last_plot_html_path is not None:
                html_files[plot_name] = self.last_plot_html_path
        result["plots"] = figures
        result["html_files"] = html_files
        result["run_id"] = actual_run_id
        result["run_dir"] = str(run_dir.resolve())
        self.stability_result = result
        return result

    def save_analysis_result(
        self,
        runner_id: Annotated[str | int, Field(description="CloudPSS runner ID")],
        cloudpss_model: Annotated[str, Field(description="完整模型 RID")],
        fault: Annotated[dict[str, Any], Field(description="实际故障信息")],
        simulation: Annotated[dict[str, Any], Field(description="暂态仿真参数")],
        power_flow: Annotated[dict[str, Any], Field(description="潮流参数与状态")],
        artifacts: Annotated[dict[str, Any], Field(description="HDF5 和 HTML 文件索引")],
        timestamp: Annotated[str | None, Field(description="本次分析统一时间戳")] = None,
        save_path: Annotated[str | os.PathLike[str] | None, Field(description="本地结果根目录；未指定时使用项目根目录/results")] = None,
        run_id: Annotated[str | None, Field(description="本次分析唯一标识；未指定时自动生成")] = None,
    ) -> dict[str, Any]:
        """将最终稳定性结论、故障信息、运行参数和文件索引保存为 JSON。"""
        if self.stability_result is None:
            raise ValueError("尚无稳定性检查结果，请先调用 extract_and_check_data()")
        timestamp_text = timestamp or time.strftime("%Y%m%d_%H%M%S")
        actual_run_id, run_dir = self._ensure_run_context(
            timestamp=timestamp_text,
            save_path=save_path,
            run_id=run_id,
        )
        stability = {
            key: bool(self.stability_result[key])
            for key in (
                "voltage_ok",
                "frequency_ok",
                "power_angle_ok",
            )
        }
        overall_pass = all(stability.values())
        created_at = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        summary = {
            # v2：stability 仅保存三项判据，overall_pass 提升为顶层汇总字段。
            "schema_version": 2,
            "run_id": actual_run_id,
            "created_at": created_at,
            "project": {
                "model": cloudpss_model,
                "project_key": str(self.config["model"]),
            },
            "runner": {
                "runner_id": str(runner_id),
                "status": "completed",
            },
            "fault": fault,
            "simulation": simulation,
            "power_flow": power_flow,
            "stability": stability,
            # 汇总结果与三项判据同级，避免被误读为第四项判据。
            "overall_pass": overall_pass,
            "artifacts": artifacts,
        }
        output_path = (run_dir / "analysis_result.json").resolve()
        summary["artifacts"] = dict(summary["artifacts"])
        summary["artifacts"]["analysis_json"] = str(output_path)
        output_path.write_text(
            json.dumps(_json_safe(summary), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return _json_safe(summary)
