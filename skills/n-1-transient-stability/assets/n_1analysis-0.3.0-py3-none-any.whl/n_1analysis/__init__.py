from typing import Any

from .batch import ScenarioSpec, build_scenarios, run_batch, save_batch_result
from .n_1_analysis_toolbox import N1AnalysisToolbox

__all__ = [
    "N1AnalysisToolbox",
    "ScenarioSpec",
    "build_scenarios",
    "main",
    "main_batch",
    "run_batch",
    "save_batch_result",
]


def main() -> dict[str, Any]:
    """运行 ``demo_n1`` 中定义的完整 N-1 分析流程案例。"""
    from .demo_n1 import main as run_n1_analysis

    return run_n1_analysis()


def main_batch() -> dict[str, Any]:
    """运行 ``demo_batch_n1`` 中定义的批量 N-1 分析流程案例。"""
    from .demo_batch_n1 import main as run_batch_demo

    return run_batch_demo()
