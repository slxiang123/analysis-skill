"""CloudPSS N-1 批量暂态稳定分析编排。

本模块只提供批量域能力：场景清单构建（build_scenarios）、批量执行
与隔离（run_batch）、汇总保存（save_batch_result）。单场景 12 阶段
流程属于应用层编排：在 demo 与 skill 示例中以 ``run_scenario()``
函数实现（量测 RID、方案名等模型相关约定可在各脚本内按探查结果
调整），并通过 ``scenario_runner`` 参数注入 ``run_batch``。注入的
场景函数在全新工具箱实例上执行每个场景（隔离不变量），Ray 为可选
并行后端，未安装或初始化失败时自动回退顺序执行。
"""

from __future__ import annotations

import csv
import json
import os
import random
import re
import time
import traceback
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Literal, Mapping, Sequence

from .n_1_analysis_toolbox import N1AnalysisToolbox, _json_safe

# keys/all 模式下逐项覆盖与 defaults 均未指定时使用的确定性默认；
# random 模式不做填充，留给场景函数运行时随机回退。
DEFAULT_FAULT_PARAMS: dict[str, Any] = {
    "side": 0.0,
    "fault_start_time": 3.0,
    "cut_time": 3.1,
    "fault_type": 7,
}

_SCENARIO_FIELDS = ("side", "fault_start_time", "cut_time", "fault_type")

# 场景函数契约：run_batch 按关键字传入 token/api_url/run_id/save_path/seed
# 以及 runner_kwargs 的全部内容，返回约定键的结果字典。
ScenarioRunner = Callable[..., dict[str, Any]]


@dataclass(frozen=True)
class ScenarioSpec:
    """单个 N-1 场景的故障设定。

    故障字段为 ``None`` 表示未指定：random 模式下运行时由场景函数
    随机回退，keys/all 模式下由 :func:`build_scenarios` 填充模式
    默认值。
    """

    scenario_id: str
    label: str
    trans_key: str | None
    side: float | None = None
    fault_start_time: float | None = None
    cut_time: float | None = None
    fault_type: int | None = None


def _resolve_local_save_root(
    save_path: str | os.PathLike[str] | None = None,
) -> Path:
    """解析本地结果根目录；与工具箱保持同一语义。"""
    project_root = Path(__file__).resolve().parents[2]
    configured_root = Path(save_path) if save_path is not None else Path("results")
    return (
        configured_root
        if configured_root.is_absolute()
        else project_root / configured_root
    ).resolve()


def _validate_model_path(cloudpss_model: str) -> tuple[str, str]:
    """校验模型路径，返回拆分后的用户名和项目 key。"""
    if not cloudpss_model:
        raise ValueError("cloudpss_model 不能为空")
    parts = cloudpss_model.strip("/").split("/")
    if len(parts) != 3 or parts[0] != "model":
        raise ValueError("cloudpss_model 必须使用 model/用户名/模型标识 格式")
    return parts[1], parts[2]


def _validate_partial_overrides(source: str, values: Mapping[str, Any]) -> None:
    """拒绝未知字段，避免拼写错误被静默忽略。"""
    unknown = sorted(set(values) - set(_SCENARIO_FIELDS))
    if unknown:
        raise ValueError(
            f"{source} 包含未知字段: {', '.join(unknown)}；"
            f"可选字段为 {', '.join(_SCENARIO_FIELDS)}"
        )


def _merge_fault_field(override: Any, default: Any, mode_default: Any) -> Any:
    """按 逐项覆盖 > defaults > 模式默认 的顺序取第一个非 None 值。"""
    for value in (override, default, mode_default):
        if value is not None:
            return value
    return None


def _validate_known_fields(spec: ScenarioSpec) -> None:
    """对已明确的故障字段做区间校验（依赖 end_time 的检查在运行时进行）。"""
    if spec.side is not None and not 0 <= float(spec.side) <= 1:
        raise ValueError(f"场景 {spec.scenario_id} 的 side 必须在 0 到 1 之间")
    if spec.fault_start_time is not None and float(spec.fault_start_time) < 0:
        raise ValueError(f"场景 {spec.scenario_id} 的 fault_start_time 不能小于 0")
    if spec.fault_type is not None and not 0 <= int(spec.fault_type) <= 7:
        raise ValueError(f"场景 {spec.scenario_id} 的 fault_type 必须在 0 到 7 之间")
    if (
        spec.cut_time is not None
        and spec.fault_start_time is not None
        and float(spec.cut_time) < float(spec.fault_start_time)
    ):
        raise ValueError(
            f"场景 {spec.scenario_id} 的 cut_time 不能早于 fault_start_time"
        )


def build_scenarios(
    mode: Literal["random", "keys", "all"],
    *,
    toolbox: N1AnalysisToolbox,
    count: int | None = None,
    trans_keys: Sequence[str | Mapping[str, Any]] | None = None,
    defaults: Mapping[str, Any] | None = None,
    seed: int | None = None,
) -> list[ScenarioSpec]:
    """按指定模式构建批量场景清单，只读探查、不修改模型。

    ``toolbox`` 必须是已完成 ``set_initial_conditions()`` 的只读探查
    实例（``delete_edges=False``），仅用于元件索引和 label 解析，不得
    复用于场景执行。

    三种模式：

    - ``random``：随机采样 ``count`` 组故障元件。未给 ``seed`` 时元件
      在各场景运行时随机选择；给定 ``seed`` 时在此预采样（独立随机源，
      可能重复），保证批量前即可审计元件清单。
    - ``keys``：遍历 ``trans_keys`` 列表，元素为元件 key/label 字符串，
      或 ``{"trans_key": ..., "side": ..., ...}`` 形式的逐项覆盖字典。
    - ``all``：遍历当前算例全部交流线路与变压器。

    故障字段取值合并顺序：逐项覆盖 > ``defaults`` > 模式默认。keys/all
    模式的默认为 ``side=0.0, fault_start_time=3.0, cut_time=3.1,
    fault_type=7``；random 模式默认留空（运行时随机回退）。

    Returns:
        list[ScenarioSpec]：按顺序编号（s0000 起）的场景清单。

    Raises:
        ValueError: 模式参数缺失/非法，或覆盖字段未知/越界。
        RuntimeError: 模型中没有交流线路或变压器（random/all 模式）。
    """
    if mode not in ("random", "keys", "all"):
        raise ValueError("mode 只支持 random、keys 或 all")
    merged_defaults: dict[str, Any] = {field: None for field in _SCENARIO_FIELDS}
    if defaults is not None:
        _validate_partial_overrides("defaults", defaults)
        for field in _SCENARIO_FIELDS:
            merged_defaults[field] = defaults.get(field)

    specs: list[ScenarioSpec] = []
    if mode == "random":
        if count is None or int(count) < 1:
            raise ValueError("random 模式必须通过 count 指定不少于 1 个场景")
        keys_index = toolbox.get_transmission_keys()
        candidates = [*keys_index["acline_keys"], *keys_index["trans_keys"]]
        if not candidates:
            raise RuntimeError("当前模型没有可用于 N-1 故障的线路或变压器")
        rng = random.Random(seed) if seed is not None else None
        for index in range(int(count)):
            if rng is not None:
                trans_key: str | None = rng.choice(candidates)
                label = trans_key
            else:
                trans_key = None
                label = f"random-{index}"
            specs.append(
                ScenarioSpec(
                    scenario_id=f"s{index:04d}",
                    label=label,
                    trans_key=trans_key,
                    side=merged_defaults["side"],
                    fault_start_time=merged_defaults["fault_start_time"],
                    cut_time=merged_defaults["cut_time"],
                    fault_type=merged_defaults["fault_type"],
                )
            )
    elif mode == "keys":
        if not trans_keys:
            raise ValueError("keys 模式必须提供非空 trans_keys 列表")
        keys_index = toolbox.get_transmission_keys()
        valid_keys = {*keys_index["acline_keys"], *keys_index["trans_keys"]}
        for index, item in enumerate(trans_keys):
            overrides: dict[str, Any] = {field: None for field in _SCENARIO_FIELDS}
            if isinstance(item, Mapping):
                _validate_partial_overrides(
                    f"trans_keys[{index}]", set(item) - {"trans_key"}
                )
                raw_key = item.get("trans_key")
                if not isinstance(raw_key, str) or not raw_key.strip():
                    raise ValueError(
                        f"trans_keys[{index}] 必须包含非空 trans_key 字符串"
                    )
                raw_key = raw_key.strip()
                for field in _SCENARIO_FIELDS:
                    overrides[field] = item.get(field)
            elif isinstance(item, str):
                raw_key = item.strip()
                if not raw_key:
                    raise ValueError(f"trans_keys[{index}] 不能为空字符串")
            else:
                raise TypeError(
                    f"trans_keys[{index}] 必须是字符串或覆盖字典，实际为 "
                    f"{type(item).__name__}"
                )
            resolved = toolbox.resolve_component_key(raw_key)
            if resolved not in valid_keys:
                raise ValueError(
                    f"trans_keys[{index}]（{raw_key} -> {resolved}）"
                    "不是交流线路或变压器"
                )
            specs.append(
                ScenarioSpec(
                    scenario_id=f"s{index:04d}",
                    label=raw_key,
                    trans_key=resolved,
                    **{
                        field: _merge_fault_field(
                            overrides[field],
                            merged_defaults[field],
                            DEFAULT_FAULT_PARAMS[field],
                        )
                        for field in _SCENARIO_FIELDS
                    },
                )
            )
    else:  # all
        keys_index = toolbox.get_transmission_keys()
        candidates = [*keys_index["acline_keys"], *keys_index["trans_keys"]]
        if not candidates:
            raise RuntimeError("当前模型没有可用于 N-1 故障的线路或变压器")
        for index, key in enumerate(candidates):
            specs.append(
                ScenarioSpec(
                    scenario_id=f"s{index:04d}",
                    label=key,
                    trans_key=key,
                    **{
                        field: _merge_fault_field(
                            None,
                            merged_defaults[field],
                            DEFAULT_FAULT_PARAMS[field],
                        )
                        for field in _SCENARIO_FIELDS
                    },
                )
            )

    for spec in specs:
        _validate_known_fields(spec)
    return specs


def _run_scenario_guarded(
    cloudpss_model: str,
    scenario: ScenarioSpec,
    *,
    scenario_runner: ScenarioRunner,
    token: str | None,
    api_url: str | None,
    run_id: str | None,
    save_path: str | os.PathLike[str] | None,
    seed: int | None,
    runner_kwargs: dict[str, Any],
    index: int,
    total: int,
) -> dict[str, Any]:
    """执行单场景并把异常收敛为 failed 记录，保证整批可继续。

    从场景函数返回值中按约定键提取汇总所需信息（fault_params、
    stability_result 三判据、saved_files.analysis_json、run_id、
    run_dir、runner_id），缺失的键按空值记录。
    """
    started = time.time()
    try:
        result = scenario_runner(
            cloudpss_model,
            scenario,
            token=token,
            api_url=api_url,
            run_id=run_id,
            save_path=save_path,
            seed=seed,
            **runner_kwargs,
        )
    except Exception as error:  # 单场景失败不拖垮整批
        elapsed = round(time.time() - started, 1)
        traceback.print_exc()
        print(
            f"[batch] 场景 {scenario.scenario_id}（{scenario.label}）失败: "
            f"{type(error).__name__}: {error}，用时 {elapsed}s",
            flush=True,
        )
        return {
            "scenario_id": scenario.scenario_id,
            "label": scenario.label,
            "status": "failed",
            "fault_params": None,
            "runner_id": None,
            "run_id": run_id,
            "run_dir": None,
            "analysis_json": None,
            "stability": None,
            "overall_pass": None,
            "elapsed_seconds": elapsed,
            "error": str(error),
            "error_type": type(error).__name__,
        }
    stability_result = result.get("stability_result") or {}
    stability = {
        key: bool(stability_result.get(key))
        for key in ("voltage_ok", "frequency_ok", "power_angle_ok")
    }
    saved_files = result.get("saved_files") or {}
    return {
        "scenario_id": scenario.scenario_id,
        "label": scenario.label,
        "status": "success",
        "fault_params": _json_safe(result.get("fault_params") or {}),
        "runner_id": result.get("runner_id"),
        "run_id": result.get("run_id") or run_id,
        "run_dir": result.get("run_dir"),
        "analysis_json": saved_files.get("analysis_json"),
        "stability": stability,
        "overall_pass": all(stability.values()),
        "elapsed_seconds": round(time.time() - started, 1),
        "error": None,
        "error_type": None,
    }


def run_batch(
    cloudpss_model: str,
    scenarios: Sequence[ScenarioSpec],
    *,
    scenario_runner: ScenarioRunner,
    token: str | None = None,
    api_url: str | None = None,
    runner_kwargs: Mapping[str, Any] | None = None,
    backend: Literal["sequential", "ray"] = "sequential",
    max_workers: int = 2,
    stop_on_error: bool = False,
    batch_id: str | None = None,
    save_path: str | os.PathLike[str] | None = None,
    seed: int | None = None,
) -> dict[str, Any]:
    """批量执行 N-1 场景并保存汇总结果。

    ``scenario_runner`` 是应用层单场景函数（见 demo_n1.run_scenario
    与 skill 示例）：签名 ``scenario_runner(cloudpss_model, scenario,
    *, token, api_url, run_id, save_path, seed, **runner_kwargs)``，
    必须在函数内部新建 :class:`N1AnalysisToolbox` 实例执行 12 阶段
    流程（场景隔离不变量：故障设置对单次模型拉取一次性生效，实例间
    绝不共享状态），并返回包含 ``fault_params``、``stability_result``、
    ``saved_files``、``run_id``、``run_dir``、``runner_id`` 等约定键的
    字典。``runner_kwargs`` 原样透传仿真参数（end_time 等），不得与
    上述关键字重名。

    单场景异常默认收敛为 failed 记录后继续，``stop_on_error`` 为真时
    先保存部分汇总再抛出。默认顺序执行；``backend="ray"`` 时用 Ray
    任务并行（需安装 ``n-1analysis[batch]``），未安装或初始化失败自动
    回退顺序执行。给定 ``seed`` 时第 i 个场景以 ``seed + i`` 作为种子
    参数传给场景函数。

    每场景产物由场景函数写入其 ``run_id`` 对应目录（批量约定为
    ``results/{project_key}/runs/{batch_id}__{scenario_id}/``），批次
    汇总写入 ``results/{project_key}/batches/{batch_id}/``。

    Returns:
        dict：``schema_version``/``batch_id``/``created_at``/``project``/
        ``config``/``scenarios``/``summary``/``elapsed_seconds``/
        ``artifacts``。

    Raises:
        ValueError: 场景清单为空、scenario_id 重复或后端参数非法。
        RuntimeError: ``stop_on_error`` 为真且存在失败场景。
    """
    scenario_list = list(scenarios)
    if not scenario_list:
        raise ValueError("scenarios 不能为空")
    scenario_ids = [spec.scenario_id for spec in scenario_list]
    if len(set(scenario_ids)) != len(scenario_ids):
        raise ValueError("scenario_id 存在重复")
    if not callable(scenario_runner):
        raise TypeError("scenario_runner 必须是可调用的单场景函数")
    if backend not in ("sequential", "ray"):
        raise ValueError("backend 只支持 sequential 或 ray")
    if int(max_workers) < 1:
        raise ValueError("max_workers 必须 >= 1")
    passthrough_kwargs = dict(runner_kwargs or {})
    reserved = {
        "cloudpss_model",
        "scenario",
        "token",
        "api_url",
        "run_id",
        "save_path",
        "seed",
    }
    conflicting = sorted(set(passthrough_kwargs) & reserved)
    if conflicting:
        raise ValueError(
            "runner_kwargs 与批量保留关键字冲突: " + "、".join(conflicting)
        )

    _, project_key = _validate_model_path(cloudpss_model)
    if batch_id is None:
        batch_id = f"{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", batch_id):
        raise ValueError("batch_id 只能包含字母、数字、下划线、连字符和点")
    total = len(scenario_list)
    started = time.time()
    print(
        f"[batch {batch_id}] 开始批量 N-1 分析：{total} 个场景，后端 {backend}",
        flush=True,
    )

    def scenario_seed(index: int) -> int | None:
        return None if seed is None else seed + index

    records: list[dict[str, Any]] = []
    if backend == "ray":
        try:
            import ray  # 可选依赖；缺失时回退顺序执行
        except ImportError:
            print(
                "警告: 未安装 ray，已回退顺序执行；"
                '可执行 pip install "n-1analysis[batch]" 启用并行后端',
                flush=True,
            )
            backend = "sequential"
    if backend == "ray":
        try:
            if not ray.is_initialized():
                ray.init(
                    num_cpus=int(max_workers),
                    include_dashboard=False,
                    ignore_reinit_error=True,
                )
        except (OSError, RuntimeError) as error:
            print(
                f"警告: ray 初始化失败（{type(error).__name__}: {error}），"
                "已回退顺序执行",
                flush=True,
            )
            backend = "sequential"
    if backend == "ray":
        remote_scenario = ray.remote(_run_scenario_guarded)
        refs = [
            remote_scenario.remote(
                cloudpss_model,
                spec,
                scenario_runner=scenario_runner,
                token=token,
                api_url=api_url,
                run_id=f"{batch_id}__{spec.scenario_id}",
                save_path=save_path,
                seed=scenario_seed(index),
                runner_kwargs=passthrough_kwargs,
                index=index,
                total=total,
            )
            for index, spec in enumerate(scenario_list)
        ]
        # ray.get 按提交顺序返回结果。
        records = list(ray.get(refs))
    else:
        for index, spec in enumerate(scenario_list):
            print(
                f"[batch {batch_id}] ({index + 1}/{total}) 场景 "
                f"{spec.scenario_id}（{spec.label}）开始",
                flush=True,
            )
            record = _run_scenario_guarded(
                cloudpss_model,
                spec,
                scenario_runner=scenario_runner,
                token=token,
                api_url=api_url,
                run_id=f"{batch_id}__{spec.scenario_id}",
                save_path=save_path,
                seed=scenario_seed(index),
                runner_kwargs=passthrough_kwargs,
                index=index,
                total=total,
            )
            print(
                f"[batch {batch_id}] ({index + 1}/{total}) 场景 "
                f"{spec.scenario_id} 结束 status={record['status']} "
                f"用时 {record['elapsed_seconds']}s",
                flush=True,
            )
            records.append(record)
            if stop_on_error and record["status"] == "failed":
                break

    succeeded = sum(1 for record in records if record["status"] == "success")
    failed = sum(1 for record in records if record["status"] == "failed")
    passed = sum(
        1 for record in records if record["status"] == "success" and record["overall_pass"]
    )
    batch_result: dict[str, Any] = {
        "schema_version": 1,
        "batch_id": batch_id,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "project": {"model": cloudpss_model, "project_key": project_key},
        "config": {
            # backend 记录实际生效的后端（可能已从 ray 回退为 sequential）。
            "backend": backend,
            "max_workers": int(max_workers) if backend == "ray" else 1,
            "stop_on_error": bool(stop_on_error),
            "seed": seed,
            "scenario_count": total,
            "runner_kwargs": _json_safe(passthrough_kwargs),
        },
        "scenarios": records,
        "summary": {
            "total": total,
            "succeeded": succeeded,
            "failed": failed,
            "passed": passed,
            "failed_stability": succeeded - passed,
        },
        "elapsed_seconds": round(time.time() - started, 1),
    }
    batch_result["artifacts"] = save_batch_result(
        batch_result, scenario_specs=scenario_list, save_path=save_path
    )

    if stop_on_error and failed:
        first_failed = next(
            record for record in records if record["status"] == "failed"
        )
        print(
            f"[batch {batch_id}] 因场景 {first_failed['scenario_id']} 失败且 "
            "stop_on_error=True 提前终止",
            flush=True,
        )
        raise RuntimeError(
            f"场景 {first_failed['scenario_id']} 失败且 stop_on_error=True: "
            f"{first_failed['error_type']}: {first_failed['error']}"
        )
    print(
        f"[batch {batch_id}] 批量完成：{succeeded}/{total} 成功，"
        f"{passed} 个场景稳定通过，总用时 {batch_result['elapsed_seconds']}s",
        flush=True,
    )
    return batch_result


_CSV_COLUMNS = (
    "scenario_id",
    "label",
    "trans_key",
    "side",
    "fault_start_time",
    "cut_time",
    "fault_type",
    "status",
    "overall_pass",
    "voltage_ok",
    "frequency_ok",
    "power_angle_ok",
    "runner_id",
    "run_id",
    "run_dir",
    "error_type",
    "error",
)


def _csv_cell(value: Any) -> Any:
    """CSV 单元格统一 None 转 空字符串。"""
    return "" if value is None else value


def save_batch_result(
    batch_result: dict[str, Any],
    *,
    scenario_specs: Sequence[ScenarioSpec] | None = None,
    save_path: str | os.PathLike[str] | None = None,
) -> dict[str, str]:
    """将批量汇总写入 ``results/{project_key}/batches/{batch_id}/``。

    生成三个文件：``batch_result.json``（全量汇总）、
    ``batch_summary.csv``（平面表格）和 ``scenarios.json``（运行前
    场景清单审计快照，仅在提供 ``scenario_specs`` 时写入）。

    Returns:
        dict：``{"batch_dir": ..., "batch_json": ..., "batch_csv": ...,
        "scenarios_json": ...}``（未提供场景清单时不含最后一个键）。
    """
    project_key = str(batch_result["project"]["project_key"])
    batch_id = str(batch_result["batch_id"])
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", batch_id):
        raise ValueError("batch_id 只能包含字母、数字、下划线、连字符和点")
    batch_dir = (
        _resolve_local_save_root(save_path) / project_key / "batches" / batch_id
    )
    batch_dir.mkdir(parents=True, exist_ok=True)

    batch_json = (batch_dir / "batch_result.json").resolve()
    batch_json.write_text(
        json.dumps(_json_safe(batch_result), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    batch_csv = (batch_dir / "batch_summary.csv").resolve()
    with open(batch_csv, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(_CSV_COLUMNS)
        for record in batch_result["scenarios"]:
            fault = record.get("fault_params") or {}
            stability = record.get("stability") or {}
            writer.writerow(
                [
                    _csv_cell(record.get("scenario_id")),
                    _csv_cell(record.get("label")),
                    _csv_cell(fault.get("transKey")),
                    _csv_cell(fault.get("side")),
                    _csv_cell(fault.get("fault_start_time")),
                    _csv_cell(fault.get("cut_time")),
                    _csv_cell(fault.get("fault_type")),
                    _csv_cell(record.get("status")),
                    _csv_cell(record.get("overall_pass")),
                    _csv_cell(stability.get("voltage_ok")),
                    _csv_cell(stability.get("frequency_ok")),
                    _csv_cell(stability.get("power_angle_ok")),
                    _csv_cell(record.get("runner_id")),
                    _csv_cell(record.get("run_id")),
                    _csv_cell(record.get("run_dir")),
                    _csv_cell(record.get("error_type")),
                    _csv_cell(record.get("error")),
                ]
            )

    artifacts = {
        "batch_dir": str(batch_dir),
        "batch_json": str(batch_json),
        "batch_csv": str(batch_csv),
    }
    if scenario_specs is not None:
        scenarios_json = (batch_dir / "scenarios.json").resolve()
        scenarios_json.write_text(
            json.dumps(
                [_json_safe(asdict(spec)) for spec in scenario_specs],
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        artifacts["scenarios_json"] = str(scenarios_json)
    return artifacts
